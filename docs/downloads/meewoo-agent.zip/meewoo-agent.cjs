#!/usr/bin/env node
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// ../../node_modules/ws/lib/constants.js
var require_constants = __commonJS({
  "../../node_modules/ws/lib/constants.js"(exports2, module2) {
    "use strict";
    var BINARY_TYPES = ["nodebuffer", "arraybuffer", "fragments"];
    var hasBlob = typeof Blob !== "undefined";
    if (hasBlob) BINARY_TYPES.push("blob");
    module2.exports = {
      BINARY_TYPES,
      CLOSE_TIMEOUT: 3e4,
      EMPTY_BUFFER: Buffer.alloc(0),
      GUID: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11",
      hasBlob,
      kForOnEventAttribute: Symbol("kIsForOnEventAttribute"),
      kListener: Symbol("kListener"),
      kStatusCode: Symbol("status-code"),
      kWebSocket: Symbol("websocket"),
      NOOP: () => {
      }
    };
  }
});

// ../../node_modules/ws/lib/buffer-util.js
var require_buffer_util = __commonJS({
  "../../node_modules/ws/lib/buffer-util.js"(exports2, module2) {
    "use strict";
    var { EMPTY_BUFFER } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    function concat(list, totalLength) {
      if (list.length === 0) return EMPTY_BUFFER;
      if (list.length === 1) return list[0];
      const target = Buffer.allocUnsafe(totalLength);
      let offset = 0;
      for (let i = 0; i < list.length; i++) {
        const buf = list[i];
        target.set(buf, offset);
        offset += buf.length;
      }
      if (offset < totalLength) {
        return new FastBuffer(target.buffer, target.byteOffset, offset);
      }
      return target;
    }
    function _mask(source, mask, output, offset, length) {
      for (let i = 0; i < length; i++) {
        output[offset + i] = source[i] ^ mask[i & 3];
      }
    }
    function _unmask(buffer, mask) {
      for (let i = 0; i < buffer.length; i++) {
        buffer[i] ^= mask[i & 3];
      }
    }
    function toArrayBuffer(buf) {
      if (buf.length === buf.buffer.byteLength) {
        return buf.buffer;
      }
      return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length);
    }
    function toBuffer(data) {
      toBuffer.readOnly = true;
      if (Buffer.isBuffer(data)) return data;
      let buf;
      if (data instanceof ArrayBuffer) {
        buf = new FastBuffer(data);
      } else if (ArrayBuffer.isView(data)) {
        buf = new FastBuffer(data.buffer, data.byteOffset, data.byteLength);
      } else {
        buf = Buffer.from(data);
        toBuffer.readOnly = false;
      }
      return buf;
    }
    module2.exports = {
      concat,
      mask: _mask,
      toArrayBuffer,
      toBuffer,
      unmask: _unmask
    };
    if (!process.env.WS_NO_BUFFER_UTIL) {
      try {
        const bufferUtil = require("bufferutil");
        module2.exports.mask = function(source, mask, output, offset, length) {
          if (length < 48) _mask(source, mask, output, offset, length);
          else bufferUtil.mask(source, mask, output, offset, length);
        };
        module2.exports.unmask = function(buffer, mask) {
          if (buffer.length < 32) _unmask(buffer, mask);
          else bufferUtil.unmask(buffer, mask);
        };
      } catch (e) {
      }
    }
  }
});

// ../../node_modules/ws/lib/limiter.js
var require_limiter = __commonJS({
  "../../node_modules/ws/lib/limiter.js"(exports2, module2) {
    "use strict";
    var kDone = Symbol("kDone");
    var kRun = Symbol("kRun");
    var Limiter = class {
      /**
       * Creates a new `Limiter`.
       *
       * @param {Number} [concurrency=Infinity] The maximum number of jobs allowed
       *     to run concurrently
       */
      constructor(concurrency) {
        this[kDone] = () => {
          this.pending--;
          this[kRun]();
        };
        this.concurrency = concurrency || Infinity;
        this.jobs = [];
        this.pending = 0;
      }
      /**
       * Adds a job to the queue.
       *
       * @param {Function} job The job to run
       * @public
       */
      add(job) {
        this.jobs.push(job);
        this[kRun]();
      }
      /**
       * Removes a job from the queue and runs it if possible.
       *
       * @private
       */
      [kRun]() {
        if (this.pending === this.concurrency) return;
        if (this.jobs.length) {
          const job = this.jobs.shift();
          this.pending++;
          job(this[kDone]);
        }
      }
    };
    module2.exports = Limiter;
  }
});

// ../../node_modules/ws/lib/permessage-deflate.js
var require_permessage_deflate = __commonJS({
  "../../node_modules/ws/lib/permessage-deflate.js"(exports2, module2) {
    "use strict";
    var zlib = require("zlib");
    var bufferUtil = require_buffer_util();
    var Limiter = require_limiter();
    var { kStatusCode } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    var TRAILER = Buffer.from([0, 0, 255, 255]);
    var kPerMessageDeflate = Symbol("permessage-deflate");
    var kTotalLength = Symbol("total-length");
    var kCallback = Symbol("callback");
    var kBuffers = Symbol("buffers");
    var kError = Symbol("error");
    var zlibLimiter;
    var PerMessageDeflate2 = class {
      /**
       * Creates a PerMessageDeflate instance.
       *
       * @param {Object} [options] Configuration options
       * @param {(Boolean|Number)} [options.clientMaxWindowBits] Advertise support
       *     for, or request, a custom client window size
       * @param {Boolean} [options.clientNoContextTakeover=false] Advertise/
       *     acknowledge disabling of client context takeover
       * @param {Number} [options.concurrencyLimit=10] The number of concurrent
       *     calls to zlib
       * @param {Boolean} [options.isServer=false] Create the instance in either
       *     server or client mode
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {(Boolean|Number)} [options.serverMaxWindowBits] Request/confirm the
       *     use of a custom server window size
       * @param {Boolean} [options.serverNoContextTakeover=false] Request/accept
       *     disabling of server context takeover
       * @param {Number} [options.threshold=1024] Size (in bytes) below which
       *     messages should not be compressed if context takeover is disabled
       * @param {Object} [options.zlibDeflateOptions] Options to pass to zlib on
       *     deflate
       * @param {Object} [options.zlibInflateOptions] Options to pass to zlib on
       *     inflate
       */
      constructor(options) {
        this._options = options || {};
        this._threshold = this._options.threshold !== void 0 ? this._options.threshold : 1024;
        this._maxPayload = this._options.maxPayload | 0;
        this._isServer = !!this._options.isServer;
        this._deflate = null;
        this._inflate = null;
        this.params = null;
        if (!zlibLimiter) {
          const concurrency = this._options.concurrencyLimit !== void 0 ? this._options.concurrencyLimit : 10;
          zlibLimiter = new Limiter(concurrency);
        }
      }
      /**
       * @type {String}
       */
      static get extensionName() {
        return "permessage-deflate";
      }
      /**
       * Create an extension negotiation offer.
       *
       * @return {Object} Extension parameters
       * @public
       */
      offer() {
        const params = {};
        if (this._options.serverNoContextTakeover) {
          params.server_no_context_takeover = true;
        }
        if (this._options.clientNoContextTakeover) {
          params.client_no_context_takeover = true;
        }
        if (this._options.serverMaxWindowBits) {
          params.server_max_window_bits = this._options.serverMaxWindowBits;
        }
        if (this._options.clientMaxWindowBits) {
          params.client_max_window_bits = this._options.clientMaxWindowBits;
        } else if (this._options.clientMaxWindowBits == null) {
          params.client_max_window_bits = true;
        }
        return params;
      }
      /**
       * Accept an extension negotiation offer/response.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Object} Accepted configuration
       * @public
       */
      accept(configurations) {
        configurations = this.normalizeParams(configurations);
        this.params = this._isServer ? this.acceptAsServer(configurations) : this.acceptAsClient(configurations);
        return this.params;
      }
      /**
       * Releases all resources used by the extension.
       *
       * @public
       */
      cleanup() {
        if (this._inflate) {
          this._inflate.close();
          this._inflate = null;
        }
        if (this._deflate) {
          const callback = this._deflate[kCallback];
          this._deflate.close();
          this._deflate = null;
          if (callback) {
            callback(
              new Error(
                "The deflate stream was closed while data was being processed"
              )
            );
          }
        }
      }
      /**
       *  Accept an extension negotiation offer.
       *
       * @param {Array} offers The extension negotiation offers
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsServer(offers) {
        const opts = this._options;
        const accepted = offers.find((params) => {
          if (opts.serverNoContextTakeover === false && params.server_no_context_takeover || params.server_max_window_bits && (opts.serverMaxWindowBits === false || typeof opts.serverMaxWindowBits === "number" && opts.serverMaxWindowBits > params.server_max_window_bits) || typeof opts.clientMaxWindowBits === "number" && (typeof params.client_max_window_bits === "number" ? opts.clientMaxWindowBits > params.client_max_window_bits : !params.client_max_window_bits)) {
            return false;
          }
          return true;
        });
        if (!accepted) {
          throw new Error("None of the extension offers can be accepted");
        }
        if (opts.serverNoContextTakeover) {
          accepted.server_no_context_takeover = true;
        }
        if (opts.clientNoContextTakeover) {
          accepted.client_no_context_takeover = true;
        }
        if (typeof opts.serverMaxWindowBits === "number") {
          accepted.server_max_window_bits = opts.serverMaxWindowBits;
        }
        if (typeof opts.clientMaxWindowBits === "number") {
          accepted.client_max_window_bits = opts.clientMaxWindowBits;
        } else if (accepted.client_max_window_bits === true || opts.clientMaxWindowBits === false) {
          delete accepted.client_max_window_bits;
        }
        return accepted;
      }
      /**
       * Accept the extension negotiation response.
       *
       * @param {Array} response The extension negotiation response
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsClient(response) {
        const params = response[0];
        if (this._options.clientNoContextTakeover === false && params.client_no_context_takeover) {
          throw new Error('Unexpected parameter "client_no_context_takeover"');
        }
        if (!params.client_max_window_bits) {
          if (typeof this._options.clientMaxWindowBits === "number") {
            params.client_max_window_bits = this._options.clientMaxWindowBits;
          }
        } else if (this._options.clientMaxWindowBits === false || typeof this._options.clientMaxWindowBits === "number" && params.client_max_window_bits > this._options.clientMaxWindowBits) {
          throw new Error(
            'Unexpected or invalid parameter "client_max_window_bits"'
          );
        }
        return params;
      }
      /**
       * Normalize parameters.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Array} The offers/response with normalized parameters
       * @private
       */
      normalizeParams(configurations) {
        configurations.forEach((params) => {
          Object.keys(params).forEach((key) => {
            let value = params[key];
            if (value.length > 1) {
              throw new Error(`Parameter "${key}" must have only a single value`);
            }
            value = value[0];
            if (key === "client_max_window_bits") {
              if (value !== true) {
                const num = +value;
                if (!Number.isInteger(num) || num < 8 || num > 15) {
                  throw new TypeError(
                    `Invalid value for parameter "${key}": ${value}`
                  );
                }
                value = num;
              } else if (!this._isServer) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else if (key === "server_max_window_bits") {
              const num = +value;
              if (!Number.isInteger(num) || num < 8 || num > 15) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
              value = num;
            } else if (key === "client_no_context_takeover" || key === "server_no_context_takeover") {
              if (value !== true) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else {
              throw new Error(`Unknown parameter "${key}"`);
            }
            params[key] = value;
          });
        });
        return configurations;
      }
      /**
       * Decompress data. Concurrency limited.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      decompress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._decompress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Compress data. Concurrency limited.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      compress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._compress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Decompress data.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _decompress(data, fin, callback) {
        const endpoint = this._isServer ? "client" : "server";
        if (!this._inflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._inflate = zlib.createInflateRaw({
            ...this._options.zlibInflateOptions,
            windowBits
          });
          this._inflate[kPerMessageDeflate] = this;
          this._inflate[kTotalLength] = 0;
          this._inflate[kBuffers] = [];
          this._inflate.on("error", inflateOnError);
          this._inflate.on("data", inflateOnData);
        }
        this._inflate[kCallback] = callback;
        this._inflate.write(data);
        if (fin) this._inflate.write(TRAILER);
        this._inflate.flush(() => {
          const err = this._inflate[kError];
          if (err) {
            this._inflate.close();
            this._inflate = null;
            callback(err);
            return;
          }
          const data2 = bufferUtil.concat(
            this._inflate[kBuffers],
            this._inflate[kTotalLength]
          );
          if (this._inflate._readableState.endEmitted) {
            this._inflate.close();
            this._inflate = null;
          } else {
            this._inflate[kTotalLength] = 0;
            this._inflate[kBuffers] = [];
            if (fin && this.params[`${endpoint}_no_context_takeover`]) {
              this._inflate.reset();
            }
          }
          callback(null, data2);
        });
      }
      /**
       * Compress data.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _compress(data, fin, callback) {
        const endpoint = this._isServer ? "server" : "client";
        if (!this._deflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._deflate = zlib.createDeflateRaw({
            ...this._options.zlibDeflateOptions,
            windowBits
          });
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          this._deflate.on("data", deflateOnData);
        }
        this._deflate[kCallback] = callback;
        this._deflate.write(data);
        this._deflate.flush(zlib.Z_SYNC_FLUSH, () => {
          if (!this._deflate) {
            return;
          }
          let data2 = bufferUtil.concat(
            this._deflate[kBuffers],
            this._deflate[kTotalLength]
          );
          if (fin) {
            data2 = new FastBuffer(data2.buffer, data2.byteOffset, data2.length - 4);
          }
          this._deflate[kCallback] = null;
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          if (fin && this.params[`${endpoint}_no_context_takeover`]) {
            this._deflate.reset();
          }
          callback(null, data2);
        });
      }
    };
    module2.exports = PerMessageDeflate2;
    function deflateOnData(chunk) {
      this[kBuffers].push(chunk);
      this[kTotalLength] += chunk.length;
    }
    function inflateOnData(chunk) {
      this[kTotalLength] += chunk.length;
      if (this[kPerMessageDeflate]._maxPayload < 1 || this[kTotalLength] <= this[kPerMessageDeflate]._maxPayload) {
        this[kBuffers].push(chunk);
        return;
      }
      this[kError] = new RangeError("Max payload size exceeded");
      this[kError].code = "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH";
      this[kError][kStatusCode] = 1009;
      this.removeListener("data", inflateOnData);
      this.reset();
    }
    function inflateOnError(err) {
      this[kPerMessageDeflate]._inflate = null;
      if (this[kError]) {
        this[kCallback](this[kError]);
        return;
      }
      err[kStatusCode] = 1007;
      this[kCallback](err);
    }
  }
});

// ../../node_modules/ws/lib/validation.js
var require_validation = __commonJS({
  "../../node_modules/ws/lib/validation.js"(exports2, module2) {
    "use strict";
    var { isUtf8 } = require("buffer");
    var { hasBlob } = require_constants();
    var tokenChars = [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 0 - 15
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 16 - 31
      0,
      1,
      0,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      1,
      1,
      0,
      1,
      1,
      0,
      // 32 - 47
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      // 48 - 63
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 64 - 79
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      1,
      1,
      // 80 - 95
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 96 - 111
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      1,
      0,
      1,
      0
      // 112 - 127
    ];
    function isValidStatusCode(code) {
      return code >= 1e3 && code <= 1014 && code !== 1004 && code !== 1005 && code !== 1006 || code >= 3e3 && code <= 4999;
    }
    function _isValidUTF8(buf) {
      const len = buf.length;
      let i = 0;
      while (i < len) {
        if ((buf[i] & 128) === 0) {
          i++;
        } else if ((buf[i] & 224) === 192) {
          if (i + 1 === len || (buf[i + 1] & 192) !== 128 || (buf[i] & 254) === 192) {
            return false;
          }
          i += 2;
        } else if ((buf[i] & 240) === 224) {
          if (i + 2 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || buf[i] === 224 && (buf[i + 1] & 224) === 128 || // Overlong
          buf[i] === 237 && (buf[i + 1] & 224) === 160) {
            return false;
          }
          i += 3;
        } else if ((buf[i] & 248) === 240) {
          if (i + 3 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || (buf[i + 3] & 192) !== 128 || buf[i] === 240 && (buf[i + 1] & 240) === 128 || // Overlong
          buf[i] === 244 && buf[i + 1] > 143 || buf[i] > 244) {
            return false;
          }
          i += 4;
        } else {
          return false;
        }
      }
      return true;
    }
    function isBlob(value) {
      return hasBlob && typeof value === "object" && typeof value.arrayBuffer === "function" && typeof value.type === "string" && typeof value.stream === "function" && (value[Symbol.toStringTag] === "Blob" || value[Symbol.toStringTag] === "File");
    }
    module2.exports = {
      isBlob,
      isValidStatusCode,
      isValidUTF8: _isValidUTF8,
      tokenChars
    };
    if (isUtf8) {
      module2.exports.isValidUTF8 = function(buf) {
        return buf.length < 24 ? _isValidUTF8(buf) : isUtf8(buf);
      };
    } else if (!process.env.WS_NO_UTF_8_VALIDATE) {
      try {
        const isValidUTF8 = require("utf-8-validate");
        module2.exports.isValidUTF8 = function(buf) {
          return buf.length < 32 ? _isValidUTF8(buf) : isValidUTF8(buf);
        };
      } catch (e) {
      }
    }
  }
});

// ../../node_modules/ws/lib/receiver.js
var require_receiver = __commonJS({
  "../../node_modules/ws/lib/receiver.js"(exports2, module2) {
    "use strict";
    var { Writable } = require("stream");
    var PerMessageDeflate2 = require_permessage_deflate();
    var {
      BINARY_TYPES,
      EMPTY_BUFFER,
      kStatusCode,
      kWebSocket
    } = require_constants();
    var { concat, toArrayBuffer, unmask } = require_buffer_util();
    var { isValidStatusCode, isValidUTF8 } = require_validation();
    var FastBuffer = Buffer[Symbol.species];
    var GET_INFO = 0;
    var GET_PAYLOAD_LENGTH_16 = 1;
    var GET_PAYLOAD_LENGTH_64 = 2;
    var GET_MASK = 3;
    var GET_DATA = 4;
    var INFLATING = 5;
    var DEFER_EVENT = 6;
    var Receiver2 = class extends Writable {
      /**
       * Creates a Receiver instance.
       *
       * @param {Object} [options] Options object
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {String} [options.binaryType=nodebuffer] The type for binary data
       * @param {Object} [options.extensions] An object containing the negotiated
       *     extensions
       * @param {Boolean} [options.isServer=false] Specifies whether to operate in
       *     client or server mode
       * @param {Number} [options.maxBufferedChunks=0] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=0] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       */
      constructor(options = {}) {
        super();
        this._allowSynchronousEvents = options.allowSynchronousEvents !== void 0 ? options.allowSynchronousEvents : true;
        this._binaryType = options.binaryType || BINARY_TYPES[0];
        this._extensions = options.extensions || {};
        this._isServer = !!options.isServer;
        this._maxBufferedChunks = options.maxBufferedChunks | 0;
        this._maxFragments = options.maxFragments | 0;
        this._maxPayload = options.maxPayload | 0;
        this._skipUTF8Validation = !!options.skipUTF8Validation;
        this[kWebSocket] = void 0;
        this._bufferedBytes = 0;
        this._buffers = [];
        this._compressed = false;
        this._payloadLength = 0;
        this._mask = void 0;
        this._fragmented = 0;
        this._masked = false;
        this._fin = false;
        this._opcode = 0;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._numFragments = 0;
        this._fragments = [];
        this._errored = false;
        this._loop = false;
        this._state = GET_INFO;
      }
      /**
       * Implements `Writable.prototype._write()`.
       *
       * @param {Buffer} chunk The chunk of data to write
       * @param {String} encoding The character encoding of `chunk`
       * @param {Function} cb Callback
       * @private
       */
      _write(chunk, encoding, cb) {
        if (this._opcode === 8 && this._state == GET_INFO) return cb();
        if (this._maxBufferedChunks > 0 && this._buffers.length >= this._maxBufferedChunks) {
          cb(
            this.createError(
              RangeError,
              "Too many buffered chunks",
              false,
              1008,
              "WS_ERR_TOO_MANY_BUFFERED_PARTS"
            )
          );
          return;
        }
        this._bufferedBytes += chunk.length;
        this._buffers.push(chunk);
        this.startLoop(cb);
      }
      /**
       * Consumes `n` bytes from the buffered data.
       *
       * @param {Number} n The number of bytes to consume
       * @return {Buffer} The consumed bytes
       * @private
       */
      consume(n) {
        this._bufferedBytes -= n;
        if (n === this._buffers[0].length) return this._buffers.shift();
        if (n < this._buffers[0].length) {
          const buf = this._buffers[0];
          this._buffers[0] = new FastBuffer(
            buf.buffer,
            buf.byteOffset + n,
            buf.length - n
          );
          return new FastBuffer(buf.buffer, buf.byteOffset, n);
        }
        const dst = Buffer.allocUnsafe(n);
        do {
          const buf = this._buffers[0];
          const offset = dst.length - n;
          if (n >= buf.length) {
            dst.set(this._buffers.shift(), offset);
          } else {
            dst.set(new Uint8Array(buf.buffer, buf.byteOffset, n), offset);
            this._buffers[0] = new FastBuffer(
              buf.buffer,
              buf.byteOffset + n,
              buf.length - n
            );
          }
          n -= buf.length;
        } while (n > 0);
        return dst;
      }
      /**
       * Starts the parsing loop.
       *
       * @param {Function} cb Callback
       * @private
       */
      startLoop(cb) {
        this._loop = true;
        do {
          switch (this._state) {
            case GET_INFO:
              this.getInfo(cb);
              break;
            case GET_PAYLOAD_LENGTH_16:
              this.getPayloadLength16(cb);
              break;
            case GET_PAYLOAD_LENGTH_64:
              this.getPayloadLength64(cb);
              break;
            case GET_MASK:
              this.getMask();
              break;
            case GET_DATA:
              this.getData(cb);
              break;
            case INFLATING:
            case DEFER_EVENT:
              this._loop = false;
              return;
          }
        } while (this._loop);
        if (!this._errored) cb();
      }
      /**
       * Reads the first two bytes of a frame.
       *
       * @param {Function} cb Callback
       * @private
       */
      getInfo(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        const buf = this.consume(2);
        if ((buf[0] & 48) !== 0) {
          const error = this.createError(
            RangeError,
            "RSV2 and RSV3 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_2_3"
          );
          cb(error);
          return;
        }
        const compressed = (buf[0] & 64) === 64;
        if (compressed && !this._extensions[PerMessageDeflate2.extensionName]) {
          const error = this.createError(
            RangeError,
            "RSV1 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_1"
          );
          cb(error);
          return;
        }
        this._fin = (buf[0] & 128) === 128;
        this._opcode = buf[0] & 15;
        this._payloadLength = buf[1] & 127;
        if (this._opcode === 0) {
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (!this._fragmented) {
            const error = this.createError(
              RangeError,
              "invalid opcode 0",
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._opcode = this._fragmented;
        } else if (this._opcode === 1 || this._opcode === 2) {
          if (this._fragmented) {
            const error = this.createError(
              RangeError,
              `invalid opcode ${this._opcode}`,
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._compressed = compressed;
        } else if (this._opcode > 7 && this._opcode < 11) {
          if (!this._fin) {
            const error = this.createError(
              RangeError,
              "FIN must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_FIN"
            );
            cb(error);
            return;
          }
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (this._payloadLength > 125 || this._opcode === 8 && this._payloadLength === 1) {
            const error = this.createError(
              RangeError,
              `invalid payload length ${this._payloadLength}`,
              true,
              1002,
              "WS_ERR_INVALID_CONTROL_PAYLOAD_LENGTH"
            );
            cb(error);
            return;
          }
        } else {
          const error = this.createError(
            RangeError,
            `invalid opcode ${this._opcode}`,
            true,
            1002,
            "WS_ERR_INVALID_OPCODE"
          );
          cb(error);
          return;
        }
        if (!this._fin && !this._fragmented) this._fragmented = this._opcode;
        this._masked = (buf[1] & 128) === 128;
        if (this._isServer) {
          if (!this._masked) {
            const error = this.createError(
              RangeError,
              "MASK must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_MASK"
            );
            cb(error);
            return;
          }
        } else if (this._masked) {
          const error = this.createError(
            RangeError,
            "MASK must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_MASK"
          );
          cb(error);
          return;
        }
        if (this._payloadLength === 126) this._state = GET_PAYLOAD_LENGTH_16;
        else if (this._payloadLength === 127) this._state = GET_PAYLOAD_LENGTH_64;
        else this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+16).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength16(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        this._payloadLength = this.consume(2).readUInt16BE(0);
        this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+64).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength64(cb) {
        if (this._bufferedBytes < 8) {
          this._loop = false;
          return;
        }
        const buf = this.consume(8);
        const num = buf.readUInt32BE(0);
        if (num > Math.pow(2, 53 - 32) - 1) {
          const error = this.createError(
            RangeError,
            "Unsupported WebSocket frame: payload length > 2^53 - 1",
            false,
            1009,
            "WS_ERR_UNSUPPORTED_DATA_PAYLOAD_LENGTH"
          );
          cb(error);
          return;
        }
        this._payloadLength = num * Math.pow(2, 32) + buf.readUInt32BE(4);
        this.haveLength(cb);
      }
      /**
       * Payload length has been read.
       *
       * @param {Function} cb Callback
       * @private
       */
      haveLength(cb) {
        if (this._payloadLength && this._opcode < 8) {
          this._totalPayloadLength += this._payloadLength;
          if (this._totalPayloadLength > this._maxPayload && this._maxPayload > 0) {
            const error = this.createError(
              RangeError,
              "Max payload size exceeded",
              false,
              1009,
              "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
            );
            cb(error);
            return;
          }
        }
        if (this._masked) this._state = GET_MASK;
        else this._state = GET_DATA;
      }
      /**
       * Reads mask bytes.
       *
       * @private
       */
      getMask() {
        if (this._bufferedBytes < 4) {
          this._loop = false;
          return;
        }
        this._mask = this.consume(4);
        this._state = GET_DATA;
      }
      /**
       * Reads data bytes.
       *
       * @param {Function} cb Callback
       * @private
       */
      getData(cb) {
        let data = EMPTY_BUFFER;
        if (this._payloadLength) {
          if (this._bufferedBytes < this._payloadLength) {
            this._loop = false;
            return;
          }
          data = this.consume(this._payloadLength);
          if (this._masked && (this._mask[0] | this._mask[1] | this._mask[2] | this._mask[3]) !== 0) {
            unmask(data, this._mask);
          }
        }
        if (this._opcode > 7) {
          this.controlMessage(data, cb);
          return;
        }
        if (this._maxFragments > 0 && ++this._numFragments > this._maxFragments) {
          const error = this.createError(
            RangeError,
            "Too many message fragments",
            false,
            1008,
            "WS_ERR_TOO_MANY_BUFFERED_PARTS"
          );
          cb(error);
          return;
        }
        if (this._compressed) {
          this._state = INFLATING;
          this.decompress(data, cb);
          return;
        }
        if (data.length) {
          this._messageLength = this._totalPayloadLength;
          this._fragments.push(data);
        }
        this.dataMessage(cb);
      }
      /**
       * Decompresses data.
       *
       * @param {Buffer} data Compressed data
       * @param {Function} cb Callback
       * @private
       */
      decompress(data, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        perMessageDeflate.decompress(data, this._fin, (err, buf) => {
          if (err) return cb(err);
          if (buf.length) {
            this._messageLength += buf.length;
            if (this._messageLength > this._maxPayload && this._maxPayload > 0) {
              const error = this.createError(
                RangeError,
                "Max payload size exceeded",
                false,
                1009,
                "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
              );
              cb(error);
              return;
            }
            this._fragments.push(buf);
          }
          this.dataMessage(cb);
          if (this._state === GET_INFO) this.startLoop(cb);
        });
      }
      /**
       * Handles a data message.
       *
       * @param {Function} cb Callback
       * @private
       */
      dataMessage(cb) {
        if (!this._fin) {
          this._state = GET_INFO;
          return;
        }
        const messageLength = this._messageLength;
        const fragments = this._fragments;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._fragmented = 0;
        this._numFragments = 0;
        this._fragments = [];
        if (this._opcode === 2) {
          let data;
          if (this._binaryType === "nodebuffer") {
            data = concat(fragments, messageLength);
          } else if (this._binaryType === "arraybuffer") {
            data = toArrayBuffer(concat(fragments, messageLength));
          } else if (this._binaryType === "blob") {
            data = new Blob(fragments);
          } else {
            data = fragments;
          }
          if (this._allowSynchronousEvents) {
            this.emit("message", data, true);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", data, true);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        } else {
          const buf = concat(fragments, messageLength);
          if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
            const error = this.createError(
              Error,
              "invalid UTF-8 sequence",
              true,
              1007,
              "WS_ERR_INVALID_UTF8"
            );
            cb(error);
            return;
          }
          if (this._state === INFLATING || this._allowSynchronousEvents) {
            this.emit("message", buf, false);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", buf, false);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        }
      }
      /**
       * Handles a control message.
       *
       * @param {Buffer} data Data to handle
       * @return {(Error|RangeError|undefined)} A possible error
       * @private
       */
      controlMessage(data, cb) {
        if (this._opcode === 8) {
          if (data.length === 0) {
            this._loop = false;
            this.emit("conclude", 1005, EMPTY_BUFFER);
            this.end();
          } else {
            const code = data.readUInt16BE(0);
            if (!isValidStatusCode(code)) {
              const error = this.createError(
                RangeError,
                `invalid status code ${code}`,
                true,
                1002,
                "WS_ERR_INVALID_CLOSE_CODE"
              );
              cb(error);
              return;
            }
            const buf = new FastBuffer(
              data.buffer,
              data.byteOffset + 2,
              data.length - 2
            );
            if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
              const error = this.createError(
                Error,
                "invalid UTF-8 sequence",
                true,
                1007,
                "WS_ERR_INVALID_UTF8"
              );
              cb(error);
              return;
            }
            this._loop = false;
            this.emit("conclude", code, buf);
            this.end();
          }
          this._state = GET_INFO;
          return;
        }
        if (this._allowSynchronousEvents) {
          this.emit(this._opcode === 9 ? "ping" : "pong", data);
          this._state = GET_INFO;
        } else {
          this._state = DEFER_EVENT;
          setImmediate(() => {
            this.emit(this._opcode === 9 ? "ping" : "pong", data);
            this._state = GET_INFO;
            this.startLoop(cb);
          });
        }
      }
      /**
       * Builds an error object.
       *
       * @param {function(new:Error|RangeError)} ErrorCtor The error constructor
       * @param {String} message The error message
       * @param {Boolean} prefix Specifies whether or not to add a default prefix to
       *     `message`
       * @param {Number} statusCode The status code
       * @param {String} errorCode The exposed error code
       * @return {(Error|RangeError)} The error
       * @private
       */
      createError(ErrorCtor, message, prefix, statusCode, errorCode) {
        this._loop = false;
        this._errored = true;
        const err = new ErrorCtor(
          prefix ? `Invalid WebSocket frame: ${message}` : message
        );
        Error.captureStackTrace(err, this.createError);
        err.code = errorCode;
        err[kStatusCode] = statusCode;
        return err;
      }
    };
    module2.exports = Receiver2;
  }
});

// ../../node_modules/ws/lib/sender.js
var require_sender = __commonJS({
  "../../node_modules/ws/lib/sender.js"(exports2, module2) {
    "use strict";
    var { Duplex } = require("stream");
    var { randomFillSync } = require("crypto");
    var {
      types: { isUint8Array }
    } = require("util");
    var PerMessageDeflate2 = require_permessage_deflate();
    var { EMPTY_BUFFER, kWebSocket, NOOP } = require_constants();
    var { isBlob, isValidStatusCode } = require_validation();
    var { mask: applyMask, toBuffer } = require_buffer_util();
    var kByteLength = Symbol("kByteLength");
    var maskBuffer = Buffer.alloc(4);
    var RANDOM_POOL_SIZE = 8 * 1024;
    var randomPool;
    var randomPoolPointer = RANDOM_POOL_SIZE;
    var DEFAULT = 0;
    var DEFLATING = 1;
    var GET_BLOB_DATA = 2;
    var Sender2 = class _Sender {
      /**
       * Creates a Sender instance.
       *
       * @param {Duplex} socket The connection socket
       * @param {Object} [extensions] An object containing the negotiated extensions
       * @param {Function} [generateMask] The function used to generate the masking
       *     key
       */
      constructor(socket, extensions, generateMask) {
        this._extensions = extensions || {};
        if (generateMask) {
          this._generateMask = generateMask;
          this._maskBuffer = Buffer.alloc(4);
        }
        this._socket = socket;
        this._firstFragment = true;
        this._compress = false;
        this._bufferedBytes = 0;
        this._queue = [];
        this._state = DEFAULT;
        this.onerror = NOOP;
        this[kWebSocket] = void 0;
      }
      /**
       * Frames a piece of data according to the HyBi WebSocket protocol.
       *
       * @param {(Buffer|String)} data The data to frame
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @return {(Buffer|String)[]} The framed data
       * @public
       */
      static frame(data, options) {
        let mask;
        let merge = false;
        let offset = 2;
        let skipMasking = false;
        if (options.mask) {
          mask = options.maskBuffer || maskBuffer;
          if (options.generateMask) {
            options.generateMask(mask);
          } else {
            if (randomPoolPointer === RANDOM_POOL_SIZE) {
              if (randomPool === void 0) {
                randomPool = Buffer.alloc(RANDOM_POOL_SIZE);
              }
              randomFillSync(randomPool, 0, RANDOM_POOL_SIZE);
              randomPoolPointer = 0;
            }
            mask[0] = randomPool[randomPoolPointer++];
            mask[1] = randomPool[randomPoolPointer++];
            mask[2] = randomPool[randomPoolPointer++];
            mask[3] = randomPool[randomPoolPointer++];
          }
          skipMasking = (mask[0] | mask[1] | mask[2] | mask[3]) === 0;
          offset = 6;
        }
        let dataLength;
        if (typeof data === "string") {
          if ((!options.mask || skipMasking) && options[kByteLength] !== void 0) {
            dataLength = options[kByteLength];
          } else {
            data = Buffer.from(data);
            dataLength = data.length;
          }
        } else {
          dataLength = data.length;
          merge = options.mask && options.readOnly && !skipMasking;
        }
        let payloadLength = dataLength;
        if (dataLength >= 65536) {
          offset += 8;
          payloadLength = 127;
        } else if (dataLength > 125) {
          offset += 2;
          payloadLength = 126;
        }
        const target = Buffer.allocUnsafe(merge ? dataLength + offset : offset);
        target[0] = options.fin ? options.opcode | 128 : options.opcode;
        if (options.rsv1) target[0] |= 64;
        target[1] = payloadLength;
        if (payloadLength === 126) {
          target.writeUInt16BE(dataLength, 2);
        } else if (payloadLength === 127) {
          target[2] = target[3] = 0;
          target.writeUIntBE(dataLength, 4, 6);
        }
        if (!options.mask) return [target, data];
        target[1] |= 128;
        target[offset - 4] = mask[0];
        target[offset - 3] = mask[1];
        target[offset - 2] = mask[2];
        target[offset - 1] = mask[3];
        if (skipMasking) return [target, data];
        if (merge) {
          applyMask(data, mask, target, offset, dataLength);
          return [target];
        }
        applyMask(data, mask, data, 0, dataLength);
        return [target, data];
      }
      /**
       * Sends a close message to the other peer.
       *
       * @param {Number} [code] The status code component of the body
       * @param {(String|Buffer)} [data] The message component of the body
       * @param {Boolean} [mask=false] Specifies whether or not to mask the message
       * @param {Function} [cb] Callback
       * @public
       */
      close(code, data, mask, cb) {
        let buf;
        if (code === void 0) {
          buf = EMPTY_BUFFER;
        } else if (typeof code !== "number" || !isValidStatusCode(code)) {
          throw new TypeError("First argument must be a valid error code number");
        } else if (data === void 0 || !data.length) {
          buf = Buffer.allocUnsafe(2);
          buf.writeUInt16BE(code, 0);
        } else {
          const length = Buffer.byteLength(data);
          if (length > 123) {
            throw new RangeError("The message must not be greater than 123 bytes");
          }
          buf = Buffer.allocUnsafe(2 + length);
          buf.writeUInt16BE(code, 0);
          if (typeof data === "string") {
            buf.write(data, 2);
          } else if (isUint8Array(data)) {
            buf.set(data, 2);
          } else {
            throw new TypeError("Second argument must be a string or a Uint8Array");
          }
        }
        const options = {
          [kByteLength]: buf.length,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 8,
          readOnly: false,
          rsv1: false
        };
        if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, buf, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(buf, options), cb);
        }
      }
      /**
       * Sends a ping message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      ping(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 9,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a pong message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      pong(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 10,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a data message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Object} options Options object
       * @param {Boolean} [options.binary=false] Specifies whether `data` is binary
       *     or text
       * @param {Boolean} [options.compress=false] Specifies whether or not to
       *     compress `data`
       * @param {Boolean} [options.fin=false] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Function} [cb] Callback
       * @public
       */
      send(data, options, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        let opcode = options.binary ? 2 : 1;
        let rsv1 = options.compress;
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (this._firstFragment) {
          this._firstFragment = false;
          if (rsv1 && perMessageDeflate && perMessageDeflate.params[perMessageDeflate._isServer ? "server_no_context_takeover" : "client_no_context_takeover"]) {
            rsv1 = byteLength >= perMessageDeflate._threshold;
          }
          this._compress = rsv1;
        } else {
          rsv1 = false;
          opcode = 0;
        }
        if (options.fin) this._firstFragment = true;
        const opts = {
          [kByteLength]: byteLength,
          fin: options.fin,
          generateMask: this._generateMask,
          mask: options.mask,
          maskBuffer: this._maskBuffer,
          opcode,
          readOnly,
          rsv1
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, this._compress, opts, cb]);
          } else {
            this.getBlobData(data, this._compress, opts, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, this._compress, opts, cb]);
        } else {
          this.dispatch(data, this._compress, opts, cb);
        }
      }
      /**
       * Gets the contents of a blob as binary data.
       *
       * @param {Blob} blob The blob
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     the data
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      getBlobData(blob, compress, options, cb) {
        this._bufferedBytes += options[kByteLength];
        this._state = GET_BLOB_DATA;
        blob.arrayBuffer().then((arrayBuffer) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while the blob was being read"
            );
            process.nextTick(callCallbacks, this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          const data = toBuffer(arrayBuffer);
          if (!compress) {
            this._state = DEFAULT;
            this.sendFrame(_Sender.frame(data, options), cb);
            this.dequeue();
          } else {
            this.dispatch(data, compress, options, cb);
          }
        }).catch((err) => {
          process.nextTick(onError, this, err, cb);
        });
      }
      /**
       * Dispatches a message.
       *
       * @param {(Buffer|String)} data The message to send
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     `data`
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      dispatch(data, compress, options, cb) {
        if (!compress) {
          this.sendFrame(_Sender.frame(data, options), cb);
          return;
        }
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        this._bufferedBytes += options[kByteLength];
        this._state = DEFLATING;
        perMessageDeflate.compress(data, options.fin, (_, buf) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while data was being compressed"
            );
            callCallbacks(this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          this._state = DEFAULT;
          options.readOnly = false;
          this.sendFrame(_Sender.frame(buf, options), cb);
          this.dequeue();
        });
      }
      /**
       * Executes queued send operations.
       *
       * @private
       */
      dequeue() {
        while (this._state === DEFAULT && this._queue.length) {
          const params = this._queue.shift();
          this._bufferedBytes -= params[3][kByteLength];
          Reflect.apply(params[0], this, params.slice(1));
        }
      }
      /**
       * Enqueues a send operation.
       *
       * @param {Array} params Send operation parameters.
       * @private
       */
      enqueue(params) {
        this._bufferedBytes += params[3][kByteLength];
        this._queue.push(params);
      }
      /**
       * Sends a frame.
       *
       * @param {(Buffer | String)[]} list The frame to send
       * @param {Function} [cb] Callback
       * @private
       */
      sendFrame(list, cb) {
        if (list.length === 2) {
          this._socket.cork();
          this._socket.write(list[0]);
          this._socket.write(list[1], cb);
          this._socket.uncork();
        } else {
          this._socket.write(list[0], cb);
        }
      }
    };
    module2.exports = Sender2;
    function callCallbacks(sender, err, cb) {
      if (typeof cb === "function") cb(err);
      for (let i = 0; i < sender._queue.length; i++) {
        const params = sender._queue[i];
        const callback = params[params.length - 1];
        if (typeof callback === "function") callback(err);
      }
    }
    function onError(sender, err, cb) {
      callCallbacks(sender, err, cb);
      sender.onerror(err);
    }
  }
});

// ../../node_modules/ws/lib/event-target.js
var require_event_target = __commonJS({
  "../../node_modules/ws/lib/event-target.js"(exports2, module2) {
    "use strict";
    var { kForOnEventAttribute, kListener } = require_constants();
    var kCode = Symbol("kCode");
    var kData = Symbol("kData");
    var kError = Symbol("kError");
    var kMessage = Symbol("kMessage");
    var kReason = Symbol("kReason");
    var kTarget = Symbol("kTarget");
    var kType = Symbol("kType");
    var kWasClean = Symbol("kWasClean");
    var Event = class {
      /**
       * Create a new `Event`.
       *
       * @param {String} type The name of the event
       * @throws {TypeError} If the `type` argument is not specified
       */
      constructor(type) {
        this[kTarget] = null;
        this[kType] = type;
      }
      /**
       * @type {*}
       */
      get target() {
        return this[kTarget];
      }
      /**
       * @type {String}
       */
      get type() {
        return this[kType];
      }
    };
    Object.defineProperty(Event.prototype, "target", { enumerable: true });
    Object.defineProperty(Event.prototype, "type", { enumerable: true });
    var CloseEvent = class extends Event {
      /**
       * Create a new `CloseEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {Number} [options.code=0] The status code explaining why the
       *     connection was closed
       * @param {String} [options.reason=''] A human-readable string explaining why
       *     the connection was closed
       * @param {Boolean} [options.wasClean=false] Indicates whether or not the
       *     connection was cleanly closed
       */
      constructor(type, options = {}) {
        super(type);
        this[kCode] = options.code === void 0 ? 0 : options.code;
        this[kReason] = options.reason === void 0 ? "" : options.reason;
        this[kWasClean] = options.wasClean === void 0 ? false : options.wasClean;
      }
      /**
       * @type {Number}
       */
      get code() {
        return this[kCode];
      }
      /**
       * @type {String}
       */
      get reason() {
        return this[kReason];
      }
      /**
       * @type {Boolean}
       */
      get wasClean() {
        return this[kWasClean];
      }
    };
    Object.defineProperty(CloseEvent.prototype, "code", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "reason", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "wasClean", { enumerable: true });
    var ErrorEvent = class extends Event {
      /**
       * Create a new `ErrorEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.error=null] The error that generated this event
       * @param {String} [options.message=''] The error message
       */
      constructor(type, options = {}) {
        super(type);
        this[kError] = options.error === void 0 ? null : options.error;
        this[kMessage] = options.message === void 0 ? "" : options.message;
      }
      /**
       * @type {*}
       */
      get error() {
        return this[kError];
      }
      /**
       * @type {String}
       */
      get message() {
        return this[kMessage];
      }
    };
    Object.defineProperty(ErrorEvent.prototype, "error", { enumerable: true });
    Object.defineProperty(ErrorEvent.prototype, "message", { enumerable: true });
    var MessageEvent = class extends Event {
      /**
       * Create a new `MessageEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.data=null] The message content
       */
      constructor(type, options = {}) {
        super(type);
        this[kData] = options.data === void 0 ? null : options.data;
      }
      /**
       * @type {*}
       */
      get data() {
        return this[kData];
      }
    };
    Object.defineProperty(MessageEvent.prototype, "data", { enumerable: true });
    var EventTarget = {
      /**
       * Register an event listener.
       *
       * @param {String} type A string representing the event type to listen for
       * @param {(Function|Object)} handler The listener to add
       * @param {Object} [options] An options object specifies characteristics about
       *     the event listener
       * @param {Boolean} [options.once=false] A `Boolean` indicating that the
       *     listener should be invoked at most once after being added. If `true`,
       *     the listener would be automatically removed when invoked.
       * @public
       */
      addEventListener(type, handler, options = {}) {
        for (const listener of this.listeners(type)) {
          if (!options[kForOnEventAttribute] && listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            return;
          }
        }
        let wrapper;
        if (type === "message") {
          wrapper = function onMessage(data, isBinary) {
            const event = new MessageEvent("message", {
              data: isBinary ? data : data.toString()
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "close") {
          wrapper = function onClose(code, message) {
            const event = new CloseEvent("close", {
              code,
              reason: message.toString(),
              wasClean: this._closeFrameReceived && this._closeFrameSent
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "error") {
          wrapper = function onError(error) {
            const event = new ErrorEvent("error", {
              error,
              message: error.message
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "open") {
          wrapper = function onOpen() {
            const event = new Event("open");
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else {
          return;
        }
        wrapper[kForOnEventAttribute] = !!options[kForOnEventAttribute];
        wrapper[kListener] = handler;
        if (options.once) {
          this.once(type, wrapper);
        } else {
          this.on(type, wrapper);
        }
      },
      /**
       * Remove an event listener.
       *
       * @param {String} type A string representing the event type to remove
       * @param {(Function|Object)} handler The listener to remove
       * @public
       */
      removeEventListener(type, handler) {
        for (const listener of this.listeners(type)) {
          if (listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            this.removeListener(type, listener);
            break;
          }
        }
      }
    };
    module2.exports = {
      CloseEvent,
      ErrorEvent,
      Event,
      EventTarget,
      MessageEvent
    };
    function callListener(listener, thisArg, event) {
      if (typeof listener === "object" && listener.handleEvent) {
        listener.handleEvent.call(listener, event);
      } else {
        listener.call(thisArg, event);
      }
    }
  }
});

// ../../node_modules/ws/lib/extension.js
var require_extension = __commonJS({
  "../../node_modules/ws/lib/extension.js"(exports2, module2) {
    "use strict";
    var { tokenChars } = require_validation();
    function push(dest, name, elem) {
      if (dest[name] === void 0) dest[name] = [elem];
      else dest[name].push(elem);
    }
    function parse(header) {
      const offers = /* @__PURE__ */ Object.create(null);
      let params = /* @__PURE__ */ Object.create(null);
      let mustUnescape = false;
      let isEscaping = false;
      let inQuotes = false;
      let extensionName;
      let paramName;
      let start = -1;
      let code = -1;
      let end = -1;
      let i = 0;
      for (; i < header.length; i++) {
        code = header.charCodeAt(i);
        if (extensionName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (i !== 0 && (code === 32 || code === 9)) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            const name = header.slice(start, end);
            if (code === 44) {
              push(offers, name, params);
              params = /* @__PURE__ */ Object.create(null);
            } else {
              extensionName = name;
            }
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else if (paramName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (code === 32 || code === 9) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            push(params, header.slice(start, end), true);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            start = end = -1;
          } else if (code === 61 && start !== -1 && end === -1) {
            paramName = header.slice(start, i);
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else {
          if (isEscaping) {
            if (tokenChars[code] !== 1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (start === -1) start = i;
            else if (!mustUnescape) mustUnescape = true;
            isEscaping = false;
          } else if (inQuotes) {
            if (tokenChars[code] === 1) {
              if (start === -1) start = i;
            } else if (code === 34 && start !== -1) {
              inQuotes = false;
              end = i;
            } else if (code === 92) {
              isEscaping = true;
            } else {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
          } else if (code === 34 && header.charCodeAt(i - 1) === 61) {
            inQuotes = true;
          } else if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (start !== -1 && (code === 32 || code === 9)) {
            if (end === -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            let value = header.slice(start, end);
            if (mustUnescape) {
              value = value.replace(/\\/g, "");
              mustUnescape = false;
            }
            push(params, paramName, value);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            paramName = void 0;
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        }
      }
      if (start === -1 || inQuotes || code === 32 || code === 9) {
        throw new SyntaxError("Unexpected end of input");
      }
      if (end === -1) end = i;
      const token = header.slice(start, end);
      if (extensionName === void 0) {
        push(offers, token, params);
      } else {
        if (paramName === void 0) {
          push(params, token, true);
        } else if (mustUnescape) {
          push(params, paramName, token.replace(/\\/g, ""));
        } else {
          push(params, paramName, token);
        }
        push(offers, extensionName, params);
      }
      return offers;
    }
    function format(extensions) {
      return Object.keys(extensions).map((extension2) => {
        let configurations = extensions[extension2];
        if (!Array.isArray(configurations)) configurations = [configurations];
        return configurations.map((params) => {
          return [extension2].concat(
            Object.keys(params).map((k) => {
              let values = params[k];
              if (!Array.isArray(values)) values = [values];
              return values.map((v) => v === true ? k : `${k}=${v}`).join("; ");
            })
          ).join("; ");
        }).join(", ");
      }).join(", ");
    }
    module2.exports = { format, parse };
  }
});

// ../../node_modules/ws/lib/websocket.js
var require_websocket = __commonJS({
  "../../node_modules/ws/lib/websocket.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events");
    var https = require("https");
    var http = require("http");
    var net = require("net");
    var tls = require("tls");
    var { randomBytes, createHash } = require("crypto");
    var { Duplex, Readable } = require("stream");
    var { URL } = require("url");
    var PerMessageDeflate2 = require_permessage_deflate();
    var Receiver2 = require_receiver();
    var Sender2 = require_sender();
    var { isBlob } = require_validation();
    var {
      BINARY_TYPES,
      CLOSE_TIMEOUT,
      EMPTY_BUFFER,
      GUID,
      kForOnEventAttribute,
      kListener,
      kStatusCode,
      kWebSocket,
      NOOP
    } = require_constants();
    var {
      EventTarget: { addEventListener, removeEventListener }
    } = require_event_target();
    var { format, parse } = require_extension();
    var { toBuffer } = require_buffer_util();
    var kAborted = Symbol("kAborted");
    var protocolVersions = [8, 13];
    var readyStates = ["CONNECTING", "OPEN", "CLOSING", "CLOSED"];
    var subprotocolRegex = /^[!#$%&'*+\-.0-9A-Z^_`|a-z~]+$/;
    var WebSocket2 = class _WebSocket extends EventEmitter {
      /**
       * Create a new `WebSocket`.
       *
       * @param {(String|URL)} address The URL to which to connect
       * @param {(String|String[])} [protocols] The subprotocols
       * @param {Object} [options] Connection options
       */
      constructor(address, protocols, options) {
        super();
        this._binaryType = BINARY_TYPES[0];
        this._closeCode = 1006;
        this._closeFrameReceived = false;
        this._closeFrameSent = false;
        this._closeMessage = EMPTY_BUFFER;
        this._closeTimer = null;
        this._errorEmitted = false;
        this._extensions = {};
        this._paused = false;
        this._protocol = "";
        this._readyState = _WebSocket.CONNECTING;
        this._receiver = null;
        this._sender = null;
        this._socket = null;
        if (address !== null) {
          this._bufferedAmount = 0;
          this._isServer = false;
          this._redirects = 0;
          if (protocols === void 0) {
            if (!options || options.protocols === void 0) {
              protocols = [];
            } else if (Array.isArray(options.protocols)) {
              protocols = options.protocols;
            } else {
              protocols = [options.protocols];
            }
          } else if (!Array.isArray(protocols)) {
            if (typeof protocols === "object" && protocols !== null) {
              options = protocols;
              if (options.protocols === void 0) {
                protocols = [];
              } else if (Array.isArray(options.protocols)) {
                protocols = options.protocols;
              } else {
                protocols = [options.protocols];
              }
            } else {
              protocols = [protocols];
            }
          }
          initAsClient(this, address, protocols, options);
        } else {
          this._autoPong = options.autoPong;
          this._closeTimeout = options.closeTimeout;
          this._isServer = true;
        }
      }
      /**
       * For historical reasons, the custom "nodebuffer" type is used by the default
       * instead of "blob".
       *
       * @type {String}
       */
      get binaryType() {
        return this._binaryType;
      }
      set binaryType(type) {
        if (!BINARY_TYPES.includes(type)) return;
        this._binaryType = type;
        if (this._receiver) this._receiver._binaryType = type;
      }
      /**
       * @type {Number}
       */
      get bufferedAmount() {
        if (!this._socket) return this._bufferedAmount;
        return this._socket._writableState.length + this._sender._bufferedBytes;
      }
      /**
       * @type {String}
       */
      get extensions() {
        return Object.keys(this._extensions).join();
      }
      /**
       * @type {Boolean}
       */
      get isPaused() {
        return this._paused;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onclose() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onerror() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onopen() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onmessage() {
        return null;
      }
      /**
       * @type {String}
       */
      get protocol() {
        return this._protocol;
      }
      /**
       * @type {Number}
       */
      get readyState() {
        return this._readyState;
      }
      /**
       * @type {String}
       */
      get url() {
        return this._url;
      }
      /**
       * Set up the socket and the internal resources.
       *
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Object} options Options object
       * @param {Boolean} [options.allowSynchronousEvents=false] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Number} [options.maxBufferedChunks=0] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=0] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=0] The maximum allowed message size
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @private
       */
      setSocket(socket, head, options) {
        const receiver = new Receiver2({
          allowSynchronousEvents: options.allowSynchronousEvents,
          binaryType: this.binaryType,
          extensions: this._extensions,
          isServer: this._isServer,
          maxBufferedChunks: options.maxBufferedChunks,
          maxFragments: options.maxFragments,
          maxPayload: options.maxPayload,
          skipUTF8Validation: options.skipUTF8Validation
        });
        const sender = new Sender2(socket, this._extensions, options.generateMask);
        this._receiver = receiver;
        this._sender = sender;
        this._socket = socket;
        receiver[kWebSocket] = this;
        sender[kWebSocket] = this;
        socket[kWebSocket] = this;
        receiver.on("conclude", receiverOnConclude);
        receiver.on("drain", receiverOnDrain);
        receiver.on("error", receiverOnError);
        receiver.on("message", receiverOnMessage);
        receiver.on("ping", receiverOnPing);
        receiver.on("pong", receiverOnPong);
        sender.onerror = senderOnError;
        if (socket.setTimeout) socket.setTimeout(0);
        if (socket.setNoDelay) socket.setNoDelay();
        if (head.length > 0) socket.unshift(head);
        socket.on("close", socketOnClose);
        socket.on("data", socketOnData);
        socket.on("end", socketOnEnd);
        socket.on("error", socketOnError);
        this._readyState = _WebSocket.OPEN;
        this.emit("open");
      }
      /**
       * Emit the `'close'` event.
       *
       * @private
       */
      emitClose() {
        if (!this._socket) {
          this._readyState = _WebSocket.CLOSED;
          this.emit("close", this._closeCode, this._closeMessage);
          return;
        }
        if (this._extensions[PerMessageDeflate2.extensionName]) {
          this._extensions[PerMessageDeflate2.extensionName].cleanup();
        }
        this._receiver.removeAllListeners();
        this._readyState = _WebSocket.CLOSED;
        this.emit("close", this._closeCode, this._closeMessage);
      }
      /**
       * Start a closing handshake.
       *
       *          +----------+   +-----------+   +----------+
       *     - - -|ws.close()|-->|close frame|-->|ws.close()|- - -
       *    |     +----------+   +-----------+   +----------+     |
       *          +----------+   +-----------+         |
       * CLOSING  |ws.close()|<--|close frame|<--+-----+       CLOSING
       *          +----------+   +-----------+   |
       *    |           |                        |   +---+        |
       *                +------------------------+-->|fin| - - - -
       *    |         +---+                      |   +---+
       *     - - - - -|fin|<---------------------+
       *              +---+
       *
       * @param {Number} [code] Status code explaining why the connection is closing
       * @param {(String|Buffer)} [data] The reason why the connection is
       *     closing
       * @public
       */
      close(code, data) {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this.readyState === _WebSocket.CLOSING) {
          if (this._closeFrameSent && (this._closeFrameReceived || this._receiver._writableState.errorEmitted)) {
            this._socket.end();
          }
          return;
        }
        this._sender.close(code, data, !this._isServer, (err) => {
          if (err) return;
          this._closeFrameSent = true;
          if (this._closeFrameReceived || this._receiver._writableState.errorEmitted) {
            this._socket.end();
          }
        });
        this._readyState = _WebSocket.CLOSING;
        setCloseTimer(this);
      }
      /**
       * Pause the socket.
       *
       * @public
       */
      pause() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = true;
        this._socket.pause();
      }
      /**
       * Send a ping.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the ping is sent
       * @public
       */
      ping(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.ping(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Send a pong.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the pong is sent
       * @public
       */
      pong(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.pong(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Resume the socket.
       *
       * @public
       */
      resume() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = false;
        if (!this._receiver._writableState.needDrain) this._socket.resume();
      }
      /**
       * Send a data message.
       *
       * @param {*} data The message to send
       * @param {Object} [options] Options object
       * @param {Boolean} [options.binary] Specifies whether `data` is binary or
       *     text
       * @param {Boolean} [options.compress] Specifies whether or not to compress
       *     `data`
       * @param {Boolean} [options.fin=true] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when data is written out
       * @public
       */
      send(data, options, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof options === "function") {
          cb = options;
          options = {};
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        const opts = {
          binary: typeof data !== "string",
          mask: !this._isServer,
          compress: true,
          fin: true,
          ...options
        };
        if (!this._extensions[PerMessageDeflate2.extensionName]) {
          opts.compress = false;
        }
        this._sender.send(data || EMPTY_BUFFER, opts, cb);
      }
      /**
       * Forcibly close the connection.
       *
       * @public
       */
      terminate() {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this._socket) {
          this._readyState = _WebSocket.CLOSING;
          this._socket.destroy();
        }
      }
    };
    Object.defineProperty(WebSocket2, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2.prototype, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2.prototype, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    [
      "binaryType",
      "bufferedAmount",
      "extensions",
      "isPaused",
      "protocol",
      "readyState",
      "url"
    ].forEach((property) => {
      Object.defineProperty(WebSocket2.prototype, property, { enumerable: true });
    });
    ["open", "error", "close", "message"].forEach((method) => {
      Object.defineProperty(WebSocket2.prototype, `on${method}`, {
        enumerable: true,
        get() {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) return listener[kListener];
          }
          return null;
        },
        set(handler) {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) {
              this.removeListener(method, listener);
              break;
            }
          }
          if (typeof handler !== "function") return;
          this.addEventListener(method, handler, {
            [kForOnEventAttribute]: true
          });
        }
      });
    });
    WebSocket2.prototype.addEventListener = addEventListener;
    WebSocket2.prototype.removeEventListener = removeEventListener;
    module2.exports = WebSocket2;
    function initAsClient(websocket, address, protocols, options) {
      const opts = {
        allowSynchronousEvents: true,
        autoPong: true,
        closeTimeout: CLOSE_TIMEOUT,
        protocolVersion: protocolVersions[1],
        maxBufferedChunks: 256 * 1024,
        maxFragments: 16 * 1024,
        maxPayload: 100 * 1024 * 1024,
        skipUTF8Validation: false,
        perMessageDeflate: true,
        followRedirects: false,
        maxRedirects: 10,
        ...options,
        socketPath: void 0,
        hostname: void 0,
        protocol: void 0,
        protocols: void 0,
        timeout: void 0,
        method: "GET",
        host: void 0,
        path: void 0,
        port: void 0
      };
      websocket._autoPong = opts.autoPong;
      websocket._closeTimeout = opts.closeTimeout;
      if (!protocolVersions.includes(opts.protocolVersion)) {
        throw new RangeError(
          `Unsupported protocol version: ${opts.protocolVersion} (supported versions: ${protocolVersions.join(", ")})`
        );
      }
      let parsedUrl;
      if (address instanceof URL) {
        parsedUrl = address;
      } else {
        try {
          parsedUrl = new URL(address);
        } catch {
          throw new SyntaxError(`Invalid URL: ${address}`);
        }
      }
      if (parsedUrl.protocol === "http:") {
        parsedUrl.protocol = "ws:";
      } else if (parsedUrl.protocol === "https:") {
        parsedUrl.protocol = "wss:";
      }
      websocket._url = parsedUrl.href;
      const isSecure = parsedUrl.protocol === "wss:";
      const isIpcUrl = parsedUrl.protocol === "ws+unix:";
      let invalidUrlMessage;
      if (parsedUrl.protocol !== "ws:" && !isSecure && !isIpcUrl) {
        invalidUrlMessage = `The URL's protocol must be one of "ws:", "wss:", "http:", "https:", or "ws+unix:"`;
      } else if (isIpcUrl && !parsedUrl.pathname) {
        invalidUrlMessage = "The URL's pathname is empty";
      } else if (parsedUrl.hash) {
        invalidUrlMessage = "The URL contains a fragment identifier";
      }
      if (invalidUrlMessage) {
        const err = new SyntaxError(invalidUrlMessage);
        if (websocket._redirects === 0) {
          throw err;
        } else {
          emitErrorAndClose(websocket, err);
          return;
        }
      }
      const defaultPort = isSecure ? 443 : 80;
      const key = randomBytes(16).toString("base64");
      const request = isSecure ? https.request : http.request;
      const protocolSet = /* @__PURE__ */ new Set();
      let perMessageDeflate;
      opts.createConnection = opts.createConnection || (isSecure ? tlsConnect : netConnect);
      opts.defaultPort = opts.defaultPort || defaultPort;
      opts.port = parsedUrl.port || defaultPort;
      opts.host = parsedUrl.hostname.startsWith("[") ? parsedUrl.hostname.slice(1, -1) : parsedUrl.hostname;
      opts.headers = {
        ...opts.headers,
        "Sec-WebSocket-Version": opts.protocolVersion,
        "Sec-WebSocket-Key": key,
        Connection: "Upgrade",
        Upgrade: "websocket"
      };
      opts.path = parsedUrl.pathname + parsedUrl.search;
      opts.timeout = opts.handshakeTimeout;
      if (opts.perMessageDeflate) {
        perMessageDeflate = new PerMessageDeflate2({
          ...opts.perMessageDeflate,
          isServer: false,
          maxPayload: opts.maxPayload
        });
        opts.headers["Sec-WebSocket-Extensions"] = format({
          [PerMessageDeflate2.extensionName]: perMessageDeflate.offer()
        });
      }
      if (protocols.length) {
        for (const protocol of protocols) {
          if (typeof protocol !== "string" || !subprotocolRegex.test(protocol) || protocolSet.has(protocol)) {
            throw new SyntaxError(
              "An invalid or duplicated subprotocol was specified"
            );
          }
          protocolSet.add(protocol);
        }
        opts.headers["Sec-WebSocket-Protocol"] = protocols.join(",");
      }
      if (opts.origin) {
        if (opts.protocolVersion < 13) {
          opts.headers["Sec-WebSocket-Origin"] = opts.origin;
        } else {
          opts.headers.Origin = opts.origin;
        }
      }
      if (parsedUrl.username || parsedUrl.password) {
        opts.auth = `${parsedUrl.username}:${parsedUrl.password}`;
      }
      if (isIpcUrl) {
        const parts = opts.path.split(":");
        opts.socketPath = parts[0];
        opts.path = parts[1];
      }
      let req;
      if (opts.followRedirects) {
        if (websocket._redirects === 0) {
          websocket._originalIpc = isIpcUrl;
          websocket._originalSecure = isSecure;
          websocket._originalHostOrSocketPath = isIpcUrl ? opts.socketPath : parsedUrl.host;
          const headers = options && options.headers;
          options = { ...options, headers: {} };
          if (headers) {
            for (const [key2, value] of Object.entries(headers)) {
              options.headers[key2.toLowerCase()] = value;
            }
          }
        } else if (websocket.listenerCount("redirect") === 0) {
          const isSameHost = isIpcUrl ? websocket._originalIpc ? opts.socketPath === websocket._originalHostOrSocketPath : false : websocket._originalIpc ? false : parsedUrl.host === websocket._originalHostOrSocketPath;
          if (!isSameHost || websocket._originalSecure && !isSecure) {
            delete opts.headers.authorization;
            delete opts.headers.cookie;
            if (!isSameHost) delete opts.headers.host;
            opts.auth = void 0;
          }
        }
        if (opts.auth && !options.headers.authorization) {
          options.headers.authorization = "Basic " + Buffer.from(opts.auth).toString("base64");
        }
        req = websocket._req = request(opts);
        if (websocket._redirects) {
          websocket.emit("redirect", websocket.url, req);
        }
      } else {
        req = websocket._req = request(opts);
      }
      if (opts.timeout) {
        req.on("timeout", () => {
          abortHandshake(websocket, req, "Opening handshake has timed out");
        });
      }
      req.on("error", (err) => {
        if (req === null || req[kAborted]) return;
        req = websocket._req = null;
        emitErrorAndClose(websocket, err);
      });
      req.on("response", (res) => {
        const location = res.headers.location;
        const statusCode = res.statusCode;
        if (location && opts.followRedirects && statusCode >= 300 && statusCode < 400) {
          if (++websocket._redirects > opts.maxRedirects) {
            abortHandshake(websocket, req, "Maximum redirects exceeded");
            return;
          }
          req.abort();
          let addr;
          try {
            addr = new URL(location, address);
          } catch (e) {
            const err = new SyntaxError(`Invalid URL: ${location}`);
            emitErrorAndClose(websocket, err);
            return;
          }
          initAsClient(websocket, addr, protocols, options);
        } else if (!websocket.emit("unexpected-response", req, res)) {
          abortHandshake(
            websocket,
            req,
            `Unexpected server response: ${res.statusCode}`
          );
        }
      });
      req.on("upgrade", (res, socket, head) => {
        websocket.emit("upgrade", res);
        if (websocket.readyState !== WebSocket2.CONNECTING) return;
        req = websocket._req = null;
        const upgrade = res.headers.upgrade;
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          abortHandshake(websocket, socket, "Invalid Upgrade header");
          return;
        }
        const digest = createHash("sha1").update(key + GUID).digest("base64");
        if (res.headers["sec-websocket-accept"] !== digest) {
          abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Accept header");
          return;
        }
        const serverProt = res.headers["sec-websocket-protocol"];
        let protError;
        if (serverProt !== void 0) {
          if (!protocolSet.size) {
            protError = "Server sent a subprotocol but none was requested";
          } else if (!protocolSet.has(serverProt)) {
            protError = "Server sent an invalid subprotocol";
          }
        } else if (protocolSet.size) {
          protError = "Server sent no subprotocol";
        }
        if (protError) {
          abortHandshake(websocket, socket, protError);
          return;
        }
        if (serverProt) websocket._protocol = serverProt;
        const secWebSocketExtensions = res.headers["sec-websocket-extensions"];
        if (secWebSocketExtensions !== void 0) {
          if (!perMessageDeflate) {
            const message = "Server sent a Sec-WebSocket-Extensions header but no extension was requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          let extensions;
          try {
            extensions = parse(secWebSocketExtensions);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          const extensionNames = Object.keys(extensions);
          if (extensionNames.length !== 1 || extensionNames[0] !== PerMessageDeflate2.extensionName) {
            const message = "Server indicated an extension that was not requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          try {
            perMessageDeflate.accept(extensions[PerMessageDeflate2.extensionName]);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          websocket._extensions[PerMessageDeflate2.extensionName] = perMessageDeflate;
        }
        websocket.setSocket(socket, head, {
          allowSynchronousEvents: opts.allowSynchronousEvents,
          generateMask: opts.generateMask,
          maxBufferedChunks: opts.maxBufferedChunks,
          maxFragments: opts.maxFragments,
          maxPayload: opts.maxPayload,
          skipUTF8Validation: opts.skipUTF8Validation
        });
      });
      if (opts.finishRequest) {
        opts.finishRequest(req, websocket);
      } else {
        req.end();
      }
    }
    function emitErrorAndClose(websocket, err) {
      websocket._readyState = WebSocket2.CLOSING;
      websocket._errorEmitted = true;
      websocket.emit("error", err);
      websocket.emitClose();
    }
    function netConnect(options) {
      options.path = options.socketPath;
      return net.connect(options);
    }
    function tlsConnect(options) {
      options.path = void 0;
      if (!options.servername && options.servername !== "") {
        options.servername = net.isIP(options.host) ? "" : options.host;
      }
      return tls.connect(options);
    }
    function abortHandshake(websocket, stream, message) {
      websocket._readyState = WebSocket2.CLOSING;
      const err = new Error(message);
      Error.captureStackTrace(err, abortHandshake);
      if (stream.setHeader) {
        stream[kAborted] = true;
        stream.abort();
        if (stream.socket && !stream.socket.destroyed) {
          stream.socket.destroy();
        }
        process.nextTick(emitErrorAndClose, websocket, err);
      } else {
        stream.destroy(err);
        stream.once("error", websocket.emit.bind(websocket, "error"));
        stream.once("close", websocket.emitClose.bind(websocket));
      }
    }
    function sendAfterClose(websocket, data, cb) {
      if (data) {
        const length = isBlob(data) ? data.size : toBuffer(data).length;
        if (websocket._socket) websocket._sender._bufferedBytes += length;
        else websocket._bufferedAmount += length;
      }
      if (cb) {
        const err = new Error(
          `WebSocket is not open: readyState ${websocket.readyState} (${readyStates[websocket.readyState]})`
        );
        process.nextTick(cb, err);
      }
    }
    function receiverOnConclude(code, reason) {
      const websocket = this[kWebSocket];
      websocket._closeFrameReceived = true;
      websocket._closeMessage = reason;
      websocket._closeCode = code;
      if (websocket._socket[kWebSocket] === void 0) return;
      websocket._socket.removeListener("data", socketOnData);
      process.nextTick(resume, websocket._socket);
      if (code === 1005) websocket.close();
      else websocket.close(code, reason);
    }
    function receiverOnDrain() {
      const websocket = this[kWebSocket];
      if (!websocket.isPaused) websocket._socket.resume();
    }
    function receiverOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket._socket[kWebSocket] !== void 0) {
        websocket._socket.removeListener("data", socketOnData);
        process.nextTick(resume, websocket._socket);
        websocket.close(err[kStatusCode]);
      }
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function receiverOnFinish() {
      this[kWebSocket].emitClose();
    }
    function receiverOnMessage(data, isBinary) {
      this[kWebSocket].emit("message", data, isBinary);
    }
    function receiverOnPing(data) {
      const websocket = this[kWebSocket];
      if (websocket._autoPong) websocket.pong(data, !this._isServer, NOOP);
      websocket.emit("ping", data);
    }
    function receiverOnPong(data) {
      this[kWebSocket].emit("pong", data);
    }
    function resume(stream) {
      stream.resume();
    }
    function senderOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket.readyState === WebSocket2.CLOSED) return;
      if (websocket.readyState === WebSocket2.OPEN) {
        websocket._readyState = WebSocket2.CLOSING;
        setCloseTimer(websocket);
      }
      this._socket.end();
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function setCloseTimer(websocket) {
      websocket._closeTimer = setTimeout(
        websocket._socket.destroy.bind(websocket._socket),
        websocket._closeTimeout
      );
    }
    function socketOnClose() {
      const websocket = this[kWebSocket];
      this.removeListener("close", socketOnClose);
      this.removeListener("data", socketOnData);
      this.removeListener("end", socketOnEnd);
      websocket._readyState = WebSocket2.CLOSING;
      if (!this._readableState.endEmitted && !websocket._closeFrameReceived && !websocket._receiver._writableState.errorEmitted && this._readableState.length !== 0) {
        const chunk = this.read(this._readableState.length);
        websocket._receiver.write(chunk);
      }
      websocket._receiver.end();
      this[kWebSocket] = void 0;
      clearTimeout(websocket._closeTimer);
      if (websocket._receiver._writableState.finished || websocket._receiver._writableState.errorEmitted) {
        websocket.emitClose();
      } else {
        websocket._receiver.on("error", receiverOnFinish);
        websocket._receiver.on("finish", receiverOnFinish);
      }
    }
    function socketOnData(chunk) {
      if (!this[kWebSocket]._receiver.write(chunk)) {
        this.pause();
      }
    }
    function socketOnEnd() {
      const websocket = this[kWebSocket];
      websocket._readyState = WebSocket2.CLOSING;
      websocket._receiver.end();
      this.end();
    }
    function socketOnError() {
      const websocket = this[kWebSocket];
      this.removeListener("error", socketOnError);
      this.on("error", NOOP);
      if (websocket) {
        websocket._readyState = WebSocket2.CLOSING;
        this.destroy();
      }
    }
  }
});

// ../../node_modules/ws/lib/stream.js
var require_stream = __commonJS({
  "../../node_modules/ws/lib/stream.js"(exports2, module2) {
    "use strict";
    var WebSocket2 = require_websocket();
    var { Duplex } = require("stream");
    function emitClose(stream) {
      stream.emit("close");
    }
    function duplexOnEnd() {
      if (!this.destroyed && this._writableState.finished) {
        this.destroy();
      }
    }
    function duplexOnError(err) {
      this.removeListener("error", duplexOnError);
      this.destroy();
      if (this.listenerCount("error") === 0) {
        this.emit("error", err);
      }
    }
    function createWebSocketStream2(ws, options) {
      let terminateOnDestroy = true;
      const duplex = new Duplex({
        ...options,
        autoDestroy: false,
        emitClose: false,
        objectMode: false,
        writableObjectMode: false
      });
      ws.on("message", function message(msg, isBinary) {
        const data = !isBinary && duplex._readableState.objectMode ? msg.toString() : msg;
        if (!duplex.push(data)) ws.pause();
      });
      ws.once("error", function error(err) {
        if (duplex.destroyed) return;
        terminateOnDestroy = false;
        duplex.destroy(err);
      });
      ws.once("close", function close() {
        if (duplex.destroyed) return;
        duplex.push(null);
      });
      duplex._destroy = function(err, callback) {
        if (ws.readyState === ws.CLOSED) {
          callback(err);
          process.nextTick(emitClose, duplex);
          return;
        }
        let called = false;
        ws.once("error", function error(err2) {
          called = true;
          callback(err2);
        });
        ws.once("close", function close() {
          if (!called) callback(err);
          process.nextTick(emitClose, duplex);
        });
        if (terminateOnDestroy) ws.terminate();
      };
      duplex._final = function(callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open() {
            duplex._final(callback);
          });
          return;
        }
        if (ws._socket === null) return;
        if (ws._socket._writableState.finished) {
          callback();
          if (duplex._readableState.endEmitted) duplex.destroy();
        } else {
          ws._socket.once("finish", function finish() {
            callback();
          });
          ws.close();
        }
      };
      duplex._read = function() {
        if (ws.isPaused) ws.resume();
      };
      duplex._write = function(chunk, encoding, callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open() {
            duplex._write(chunk, encoding, callback);
          });
          return;
        }
        ws.send(chunk, callback);
      };
      duplex.on("end", duplexOnEnd);
      duplex.on("error", duplexOnError);
      return duplex;
    }
    module2.exports = createWebSocketStream2;
  }
});

// ../../node_modules/ws/lib/subprotocol.js
var require_subprotocol = __commonJS({
  "../../node_modules/ws/lib/subprotocol.js"(exports2, module2) {
    "use strict";
    var { tokenChars } = require_validation();
    function parse(header) {
      const protocols = /* @__PURE__ */ new Set();
      let start = -1;
      let end = -1;
      let i = 0;
      for (i; i < header.length; i++) {
        const code = header.charCodeAt(i);
        if (end === -1 && tokenChars[code] === 1) {
          if (start === -1) start = i;
        } else if (i !== 0 && (code === 32 || code === 9)) {
          if (end === -1 && start !== -1) end = i;
        } else if (code === 44) {
          if (start === -1) {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
          if (end === -1) end = i;
          const protocol2 = header.slice(start, end);
          if (protocols.has(protocol2)) {
            throw new SyntaxError(`The "${protocol2}" subprotocol is duplicated`);
          }
          protocols.add(protocol2);
          start = end = -1;
        } else {
          throw new SyntaxError(`Unexpected character at index ${i}`);
        }
      }
      if (start === -1 || end !== -1) {
        throw new SyntaxError("Unexpected end of input");
      }
      const protocol = header.slice(start, i);
      if (protocols.has(protocol)) {
        throw new SyntaxError(`The "${protocol}" subprotocol is duplicated`);
      }
      protocols.add(protocol);
      return protocols;
    }
    module2.exports = { parse };
  }
});

// ../../node_modules/ws/lib/websocket-server.js
var require_websocket_server = __commonJS({
  "../../node_modules/ws/lib/websocket-server.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events");
    var http = require("http");
    var { Duplex } = require("stream");
    var { createHash } = require("crypto");
    var extension2 = require_extension();
    var PerMessageDeflate2 = require_permessage_deflate();
    var subprotocol2 = require_subprotocol();
    var WebSocket2 = require_websocket();
    var { CLOSE_TIMEOUT, GUID, kWebSocket } = require_constants();
    var keyRegex = /^[+/0-9A-Za-z]{22}==$/;
    var RUNNING = 0;
    var CLOSING = 1;
    var CLOSED = 2;
    var WebSocketServer2 = class extends EventEmitter {
      /**
       * Create a `WebSocketServer` instance.
       *
       * @param {Object} options Configuration options
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Boolean} [options.autoPong=true] Specifies whether or not to
       *     automatically send a pong in response to a ping
       * @param {Number} [options.backlog=511] The maximum length of the queue of
       *     pending connections
       * @param {Boolean} [options.clientTracking=true] Specifies whether or not to
       *     track clients
       * @param {Number} [options.closeTimeout=30000] Duration in milliseconds to
       *     wait for the closing handshake to finish after `websocket.close()` is
       *     called
       * @param {Function} [options.handleProtocols] A hook to handle protocols
       * @param {String} [options.host] The hostname where to bind the server
       * @param {Number} [options.maxBufferedChunks=262144] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=16384] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=104857600] The maximum allowed message
       *     size
       * @param {Boolean} [options.noServer=false] Enable no server mode
       * @param {String} [options.path] Accept only connections matching this path
       * @param {(Boolean|Object)} [options.perMessageDeflate=false] Enable/disable
       *     permessage-deflate
       * @param {Number} [options.port] The port where to bind the server
       * @param {(http.Server|https.Server)} [options.server] A pre-created HTTP/S
       *     server to use
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @param {Function} [options.verifyClient] A hook to reject connections
       * @param {Function} [options.WebSocket=WebSocket] Specifies the `WebSocket`
       *     class to use. It must be the `WebSocket` class or class that extends it
       * @param {Function} [callback] A listener for the `listening` event
       */
      constructor(options, callback) {
        super();
        options = {
          allowSynchronousEvents: true,
          autoPong: true,
          maxBufferedChunks: 256 * 1024,
          maxFragments: 16 * 1024,
          maxPayload: 100 * 1024 * 1024,
          skipUTF8Validation: false,
          perMessageDeflate: false,
          handleProtocols: null,
          clientTracking: true,
          closeTimeout: CLOSE_TIMEOUT,
          verifyClient: null,
          noServer: false,
          backlog: null,
          // use default (511 as implemented in net.js)
          server: null,
          host: null,
          path: null,
          port: null,
          WebSocket: WebSocket2,
          ...options
        };
        if (options.port == null && !options.server && !options.noServer || options.port != null && (options.server || options.noServer) || options.server && options.noServer) {
          throw new TypeError(
            'One and only one of the "port", "server", or "noServer" options must be specified'
          );
        }
        if (options.port != null) {
          this._server = http.createServer((req, res) => {
            const body = http.STATUS_CODES[426];
            res.writeHead(426, {
              "Content-Length": body.length,
              "Content-Type": "text/plain"
            });
            res.end(body);
          });
          this._server.listen(
            options.port,
            options.host,
            options.backlog,
            callback
          );
        } else if (options.server) {
          this._server = options.server;
        }
        if (this._server) {
          const emitConnection = this.emit.bind(this, "connection");
          this._removeListeners = addListeners(this._server, {
            listening: this.emit.bind(this, "listening"),
            error: this.emit.bind(this, "error"),
            upgrade: (req, socket, head) => {
              this.handleUpgrade(req, socket, head, emitConnection);
            }
          });
        }
        if (options.perMessageDeflate === true) options.perMessageDeflate = {};
        if (options.clientTracking) {
          this.clients = /* @__PURE__ */ new Set();
          this._shouldEmitClose = false;
        }
        this.options = options;
        this._state = RUNNING;
      }
      /**
       * Returns the bound address, the address family name, and port of the server
       * as reported by the operating system if listening on an IP socket.
       * If the server is listening on a pipe or UNIX domain socket, the name is
       * returned as a string.
       *
       * @return {(Object|String|null)} The address of the server
       * @public
       */
      address() {
        if (this.options.noServer) {
          throw new Error('The server is operating in "noServer" mode');
        }
        if (!this._server) return null;
        return this._server.address();
      }
      /**
       * Stop the server from accepting new connections and emit the `'close'` event
       * when all existing connections are closed.
       *
       * @param {Function} [cb] A one-time listener for the `'close'` event
       * @public
       */
      close(cb) {
        if (this._state === CLOSED) {
          if (cb) {
            this.once("close", () => {
              cb(new Error("The server is not running"));
            });
          }
          process.nextTick(emitClose, this);
          return;
        }
        if (cb) this.once("close", cb);
        if (this._state === CLOSING) return;
        this._state = CLOSING;
        if (this.options.noServer || this.options.server) {
          if (this._server) {
            this._removeListeners();
            this._removeListeners = this._server = null;
          }
          if (this.clients) {
            if (!this.clients.size) {
              process.nextTick(emitClose, this);
            } else {
              this._shouldEmitClose = true;
            }
          } else {
            process.nextTick(emitClose, this);
          }
        } else {
          const server = this._server;
          this._removeListeners();
          this._removeListeners = this._server = null;
          server.close(() => {
            emitClose(this);
          });
        }
      }
      /**
       * See if a given request should be handled by this server instance.
       *
       * @param {http.IncomingMessage} req Request object to inspect
       * @return {Boolean} `true` if the request is valid, else `false`
       * @public
       */
      shouldHandle(req) {
        if (this.options.path) {
          const index = req.url.indexOf("?");
          const pathname = index !== -1 ? req.url.slice(0, index) : req.url;
          if (pathname !== this.options.path) return false;
        }
        return true;
      }
      /**
       * Handle a HTTP Upgrade request.
       *
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @public
       */
      handleUpgrade(req, socket, head, cb) {
        socket.on("error", socketOnError);
        const key = req.headers["sec-websocket-key"];
        const upgrade = req.headers.upgrade;
        const version = +req.headers["sec-websocket-version"];
        if (req.method !== "GET") {
          const message = "Invalid HTTP method";
          abortHandshakeOrEmitwsClientError(this, req, socket, 405, message);
          return;
        }
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          const message = "Invalid Upgrade header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (key === void 0 || !keyRegex.test(key)) {
          const message = "Missing or invalid Sec-WebSocket-Key header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (version !== 13 && version !== 8) {
          const message = "Missing or invalid Sec-WebSocket-Version header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message, {
            "Sec-WebSocket-Version": "13, 8"
          });
          return;
        }
        if (!this.shouldHandle(req)) {
          abortHandshake(socket, 400);
          return;
        }
        const secWebSocketProtocol = req.headers["sec-websocket-protocol"];
        let protocols = /* @__PURE__ */ new Set();
        if (secWebSocketProtocol !== void 0) {
          try {
            protocols = subprotocol2.parse(secWebSocketProtocol);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Protocol header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        const secWebSocketExtensions = req.headers["sec-websocket-extensions"];
        const extensions = {};
        if (this.options.perMessageDeflate && secWebSocketExtensions !== void 0) {
          const perMessageDeflate = new PerMessageDeflate2({
            ...this.options.perMessageDeflate,
            isServer: true,
            maxPayload: this.options.maxPayload
          });
          try {
            const offers = extension2.parse(secWebSocketExtensions);
            if (offers[PerMessageDeflate2.extensionName]) {
              perMessageDeflate.accept(offers[PerMessageDeflate2.extensionName]);
              extensions[PerMessageDeflate2.extensionName] = perMessageDeflate;
            }
          } catch (err) {
            const message = "Invalid or unacceptable Sec-WebSocket-Extensions header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        if (this.options.verifyClient) {
          const info = {
            origin: req.headers[`${version === 8 ? "sec-websocket-origin" : "origin"}`],
            secure: !!(req.socket.authorized || req.socket.encrypted),
            req
          };
          if (this.options.verifyClient.length === 2) {
            this.options.verifyClient(info, (verified, code, message, headers) => {
              if (!verified) {
                return abortHandshake(socket, code || 401, message, headers);
              }
              this.completeUpgrade(
                extensions,
                key,
                protocols,
                req,
                socket,
                head,
                cb
              );
            });
            return;
          }
          if (!this.options.verifyClient(info)) return abortHandshake(socket, 401);
        }
        this.completeUpgrade(extensions, key, protocols, req, socket, head, cb);
      }
      /**
       * Upgrade the connection to WebSocket.
       *
       * @param {Object} extensions The accepted extensions
       * @param {String} key The value of the `Sec-WebSocket-Key` header
       * @param {Set} protocols The subprotocols
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @throws {Error} If called more than once with the same socket
       * @private
       */
      completeUpgrade(extensions, key, protocols, req, socket, head, cb) {
        if (!socket.readable || !socket.writable) return socket.destroy();
        if (socket[kWebSocket]) {
          throw new Error(
            "server.handleUpgrade() was called more than once with the same socket, possibly due to a misconfiguration"
          );
        }
        if (this._state > RUNNING) return abortHandshake(socket, 503);
        const digest = createHash("sha1").update(key + GUID).digest("base64");
        const headers = [
          "HTTP/1.1 101 Switching Protocols",
          "Upgrade: websocket",
          "Connection: Upgrade",
          `Sec-WebSocket-Accept: ${digest}`
        ];
        const ws = new this.options.WebSocket(null, void 0, this.options);
        if (protocols.size) {
          const protocol = this.options.handleProtocols ? this.options.handleProtocols(protocols, req) : protocols.values().next().value;
          if (protocol) {
            headers.push(`Sec-WebSocket-Protocol: ${protocol}`);
            ws._protocol = protocol;
          }
        }
        if (extensions[PerMessageDeflate2.extensionName]) {
          const params = extensions[PerMessageDeflate2.extensionName].params;
          const value = extension2.format({
            [PerMessageDeflate2.extensionName]: [params]
          });
          headers.push(`Sec-WebSocket-Extensions: ${value}`);
          ws._extensions = extensions;
        }
        this.emit("headers", headers, req);
        socket.write(headers.concat("\r\n").join("\r\n"));
        socket.removeListener("error", socketOnError);
        ws.setSocket(socket, head, {
          allowSynchronousEvents: this.options.allowSynchronousEvents,
          maxBufferedChunks: this.options.maxBufferedChunks,
          maxFragments: this.options.maxFragments,
          maxPayload: this.options.maxPayload,
          skipUTF8Validation: this.options.skipUTF8Validation
        });
        if (this.clients) {
          this.clients.add(ws);
          ws.on("close", () => {
            this.clients.delete(ws);
            if (this._shouldEmitClose && !this.clients.size) {
              process.nextTick(emitClose, this);
            }
          });
        }
        cb(ws, req);
      }
    };
    module2.exports = WebSocketServer2;
    function addListeners(server, map) {
      for (const event of Object.keys(map)) server.on(event, map[event]);
      return function removeListeners() {
        for (const event of Object.keys(map)) {
          server.removeListener(event, map[event]);
        }
      };
    }
    function emitClose(server) {
      server._state = CLOSED;
      server.emit("close");
    }
    function socketOnError() {
      this.destroy();
    }
    function abortHandshake(socket, code, message, headers) {
      message = message || http.STATUS_CODES[code];
      headers = {
        Connection: "close",
        "Content-Type": "text/html",
        "Content-Length": Buffer.byteLength(message),
        ...headers
      };
      socket.once("finish", socket.destroy);
      socket.end(
        `HTTP/1.1 ${code} ${http.STATUS_CODES[code]}\r
` + Object.keys(headers).map((h) => `${h}: ${headers[h]}`).join("\r\n") + "\r\n\r\n" + message
      );
    }
    function abortHandshakeOrEmitwsClientError(server, req, socket, code, message, headers) {
      if (server.listenerCount("wsClientError")) {
        const err = new Error(message);
        Error.captureStackTrace(err, abortHandshakeOrEmitwsClientError);
        server.emit("wsClientError", err, socket, req);
      } else {
        abortHandshake(socket, code, message, headers);
      }
    }
  }
});

// meewoo-agent.mjs
var import_node_readline = require("node:readline");

// src/cdp.mjs
var import_node_child_process = require("node:child_process");
var import_node_fs = require("node:fs");
var import_promises2 = require("node:fs/promises");
var import_node_os = __toESM(require("node:os"), 1);
var import_node_path = __toESM(require("node:path"), 1);

// ../../node_modules/ws/wrapper.mjs
var import_stream = __toESM(require_stream(), 1);
var import_extension = __toESM(require_extension(), 1);
var import_permessage_deflate = __toESM(require_permessage_deflate(), 1);
var import_receiver = __toESM(require_receiver(), 1);
var import_sender = __toESM(require_sender(), 1);
var import_subprotocol = __toESM(require_subprotocol(), 1);
var import_websocket = __toESM(require_websocket(), 1);
var import_websocket_server = __toESM(require_websocket_server(), 1);
var wrapper_default = import_websocket.default;

// src/artifacts.mjs
var PROCESS_PRESETS = Object.freeze({
  recommended: Object.freeze({
    name: "recommended",
    label: "\u63A8\u8350\u503C\u5BFC\u51FA",
    target: "dual-mp4",
    selector: ".vp-footer__actions .ui-button--recommend"
  })
});
var PROCESS_PRESET_NAMES = Object.freeze(Object.keys(PROCESS_PRESETS));
var RECOMMENDED_EFFECTS = Object.freeze({
  fade: Object.freeze({ enabled: true, in: 0.5, out: 0.5 }),
  edge: Object.freeze({ enabled: true, top: 8, bottom: 8 }),
  audio: Object.freeze({
    enabled: true,
    volume: 0.8,
    fade: Object.freeze({ enabled: true, in: 1, out: 1 })
  })
});
var PROCESS_TARGETS = Object.freeze({
  "dual-mp4": Object.freeze({
    label: "\u53CC\u901A\u9053 MP4",
    extension: ".mp4",
    namePattern: /-processed(?: \(\d+\))?\.mp4$/i
  }),
  mp4: Object.freeze({
    label: "MP4",
    extension: ".mp4",
    namePattern: /-processed(?: \(\d+\))?\.mp4$/i
  }),
  svga: Object.freeze({
    label: "SVGA",
    extension: ".svga",
    namePattern: /-processed(?: \(\d+\))?\.svga$/i
  })
});
var PROCESS_TARGET_NAMES = Object.freeze(Object.keys(PROCESS_TARGETS));
var REPLACEMENT_AUDIO_EXTENSIONS = Object.freeze([".mp3", ".wav", ".m4a", ".aac"]);
var FADE_SEC_MAX = 5;
var EDGE_PERCENT_MAX = 50;
function resolvePreset(name) {
  const preset = PROCESS_PRESETS[name];
  if (!preset) {
    throw new Error(`\u4E0D\u652F\u6301\u7684\u9884\u8BBE\uFF1A${name}\uFF1B\u53EF\u7528\uFF1A${PROCESS_PRESET_NAMES.join(", ")}`);
  }
  return preset;
}
function resolveProcessTarget(target) {
  const config = PROCESS_TARGETS[target];
  if (!config) {
    throw new Error(`\u4E0D\u652F\u6301\u7684 target\uFF1A${target}\uFF1B\u53EF\u7528\uFF1A${PROCESS_TARGET_NAMES.join(", ")}`);
  }
  return config;
}
function isPlainObject(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}
function describeType(value) {
  if (value === null) return "null";
  if (Array.isArray(value)) return "\u6570\u7EC4";
  return typeof value;
}
function assertObject(value, label) {
  if (!isPlainObject(value)) {
    throw new Error(`--effects.${label} \u9700\u8981\u4E00\u4E2A\u5BF9\u8C61\uFF0C\u6536\u5230 ${describeType(value)}`);
  }
  return value;
}
function rejectUnknownKeys(object, allowed, label) {
  const unknown = Object.keys(object).filter((key) => !allowed.includes(key));
  if (unknown.length) {
    throw new Error(`--effects.${label} \u6709\u672A\u77E5\u5B57\u6BB5\uFF1A${unknown.join(", ")}\uFF08\u53EF\u7528\uFF1A${allowed.join(", ")}\uFF09`);
  }
}
function readBoolean(value, label) {
  if (value === void 0) return null;
  if (typeof value !== "boolean") {
    throw new Error(`--effects.${label} \u9700\u8981 true / false\uFF0C\u6536\u5230 ${describeType(value)}`);
  }
  return value;
}
function readNumber(value, label, { min = -Infinity, max = Infinity } = {}) {
  if (value === void 0) return null;
  if (typeof value !== "number" || !Number.isFinite(value)) {
    throw new Error(`--effects.${label} \u9700\u8981\u6570\u5B57\uFF0C\u6536\u5230 ${describeType(value)}`);
  }
  if (value < min || value > max) {
    throw new Error(`--effects.${label} \u8D85\u51FA\u8303\u56F4 ${min}\u2013${max}\uFF1A${value}`);
  }
  return value;
}
function pickAlias(object, keys, label) {
  const present = keys.filter((key) => object[key] !== void 0);
  if (present.length > 1) {
    throw new Error(`--effects.${label} \u5B57\u6BB5\u91CD\u590D\uFF1A${present.join(" / ")}\uFF08\u53EA\u4F20\u4E00\u4E2A\uFF09`);
  }
  return present.length ? object[present[0]] : void 0;
}
function parseFadeSection(raw, label) {
  const section = assertObject(raw, label);
  rejectUnknownKeys(section, ["enabled", "in", "out", "fadeIn", "fadeOut"], label);
  return {
    enabled: readBoolean(section.enabled, `${label}.enabled`) ?? true,
    in: readNumber(pickAlias(section, ["in", "fadeIn"], `${label}.in`), `${label}.in`, { min: 0, max: FADE_SEC_MAX }),
    out: readNumber(pickAlias(section, ["out", "fadeOut"], `${label}.out`), `${label}.out`, { min: 0, max: FADE_SEC_MAX })
  };
}
function parseEdgeSection(raw) {
  const label = "edge";
  const section = assertObject(raw, label);
  rejectUnknownKeys(section, ["enabled", "top", "bottom", "topPercent", "bottomPercent"], label);
  return {
    enabled: readBoolean(section.enabled, `${label}.enabled`) ?? true,
    top: readNumber(pickAlias(section, ["top", "topPercent"], `${label}.top`), `${label}.top`, {
      min: 0,
      max: EDGE_PERCENT_MAX
    }),
    bottom: readNumber(pickAlias(section, ["bottom", "bottomPercent"], `${label}.bottom`), `${label}.bottom`, {
      min: 0,
      max: EDGE_PERCENT_MAX
    })
  };
}
function parseAudioSection(raw) {
  const label = "audio";
  const section = assertObject(raw, label);
  rejectUnknownKeys(section, ["enabled", "volume", "volumePercent", "fade"], label);
  if (section.volume !== void 0 && section.volumePercent !== void 0) {
    throw new Error("--effects.audio \u7684 volume \u4E0E volumePercent \u53EA\u80FD\u4F20\u4E00\u4E2A\uFF080\u20131 \u6216 0\u2013100\uFF09");
  }
  let volume = null;
  if (section.volume !== void 0) {
    volume = readNumber(section.volume, `${label}.volume`, { min: 0, max: 1 });
  } else if (section.volumePercent !== void 0) {
    const percent = readNumber(section.volumePercent, `${label}.volumePercent`, { min: 0, max: 100 });
    volume = Math.round(percent * 100) / 1e4;
  }
  return {
    enabled: readBoolean(section.enabled, `${label}.enabled`) ?? true,
    volume,
    fade: section.fade === void 0 ? null : parseFadeSection(section.fade, `${label}.fade`)
  };
}
function parseProcessEffects(raw) {
  let data = raw;
  if (typeof raw === "string") {
    if (!raw.trim()) throw new Error("--effects \u4E0D\u80FD\u662F\u7A7A\u5B57\u7B26\u4E32");
    try {
      data = JSON.parse(raw);
    } catch (error) {
      throw new Error(`--effects \u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${error.message}`);
    }
  }
  assertObject(data, "(\u6839)");
  rejectUnknownKeys(data, ["fade", "edge", "audio"], "(\u6839)");
  if (!data.fade && !data.edge && !data.audio) {
    throw new Error("--effects \u81F3\u5C11\u8981\u6709 fade / edge / audio \u5176\u4E2D\u4E00\u6BB5");
  }
  return {
    fade: data.fade === void 0 ? null : parseFadeSection(data.fade, "fade"),
    edge: data.edge === void 0 ? null : parseEdgeSection(data.edge),
    audio: data.audio === void 0 ? null : parseAudioSection(data.audio)
  };
}
function resolveProcessPlan({ preset, effects, target, replacement } = {}) {
  const hasPreset = preset !== void 0 && preset !== null && preset !== "";
  const hasEffects = effects !== void 0 && effects !== null;
  const hasTarget = target !== void 0 && target !== null && target !== "";
  const hasReplacement = replacement !== void 0 && replacement !== null && replacement !== "";
  if (hasPreset && (hasEffects || hasTarget || hasReplacement)) {
    throw new Error("--preset \u4E0D\u80FD\u548C --effects / --target / --replacement \u540C\u65F6\u4F7F\u7528");
  }
  if (!hasPreset && !hasEffects && !hasTarget && !hasReplacement) {
    throw new Error("\u9700\u8981 --preset <recommended>\uFF0C\u6216\u81F3\u5C11\u4E00\u4E2A --effects / --target / --replacement");
  }
  if (hasPreset) {
    const presetConfig = resolvePreset(String(preset));
    return {
      mode: "preset",
      preset: presetConfig,
      target: presetConfig.target,
      effects: null,
      replacement: null
    };
  }
  const resolvedTarget = hasTarget ? String(target) : "dual-mp4";
  resolveProcessTarget(resolvedTarget);
  return {
    mode: "custom",
    preset: null,
    target: resolvedTarget,
    // 不传 effects = 推荐预设；传了则只写显式段，其余保持页面默认
    effects: hasEffects ? parseProcessEffects(effects) : RECOMMENDED_EFFECTS,
    replacement: hasReplacement ? String(replacement) : null
  };
}
function assertReplacementAudioExtension(filePath) {
  const name = String(filePath || "");
  const lower = name.toLowerCase();
  const matched = REPLACEMENT_AUDIO_EXTENSIONS.find((ext) => lower.endsWith(ext));
  if (!matched) {
    throw new Error(
      `\u66FF\u6362\u97F3\u9891\u53EA\u652F\u6301 ${REPLACEMENT_AUDIO_EXTENSIONS.join(" / ")}\uFF1A${name}\uFF08\u9875\u9762\u97F3\u9891\u66FF\u6362\u53EA\u8BA4\u8FD9\u56DB\u79CD\uFF09`
    );
  }
  return matched;
}
function expectedProcessedName(inputFileName, extension2 = ".mp4") {
  const ext = String(extension2 || ".mp4").startsWith(".") ? String(extension2) : `.${extension2}`;
  return `${sanitizeBaseName(inputFileName)}-processed${ext}`;
}
function createDownloadBaseline(fileNames = []) {
  return new Set(fileNames);
}
function isCompleteDownloadName(name) {
  return !/\.(crdownload|tmp|part)$/i.test(String(name || ""));
}
function selectNewArtifact({
  baseline,
  fileNames = [],
  extension: extension2 = "",
  expectedName = null,
  namePattern = null
} = {}) {
  const base = baseline instanceof Set ? baseline : new Set(baseline || []);
  const ext = extension2 ? String(extension2).toLowerCase() : "";
  const candidates = fileNames.filter((name) => {
    if (base.has(name)) return false;
    if (!isCompleteDownloadName(name)) return false;
    if (ext && !name.toLowerCase().endsWith(ext)) return false;
    if (namePattern && !namePattern.test(name)) return false;
    return true;
  });
  if (!candidates.length) return null;
  if (expectedName) {
    const exact = candidates.find((name) => name === expectedName);
    if (exact) return { name: exact, match: "expected" };
  }
  return { name: [...candidates].sort()[0], match: "pattern" };
}
function sanitizeBaseName(fileName) {
  const trimmed = String(fileName || "").trim();
  const withoutExtension = trimmed.replace(/\.[^.]+$/, "");
  const normalized = withoutExtension.replace(/[\\/:*?"<>|]+/g, "_").trim();
  return normalized || "\u672A\u547D\u540D\u6587\u4EF6";
}

// src/export-status.mjs
var EXPORT_STATUS_SELECTORS = Object.freeze({
  /**
   * 右上角导出队列（2026-10-30 统一队列）。
   * 视频处理确认导出后两层浮层都会关闭，进度 / 失败 / 下载都在这张队列卡里。
   */
  queue: Object.freeze({
    root: ".export-queue",
    success: ".export-queue .conversion-progress-download",
    successButton: true,
    failure: ".export-queue .export-queue__failure-reason",
    running: ".export-queue__item.is-running, .export-queue__item.is-preparing, .export-queue__item.is-pending",
    resultName: ".export-queue .export-queue__file",
    progressText: ".export-queue .export-queue__percent"
  }),
  /** 旧版视频处理底栏（2026-11-01 入口迁移前的状态口；保留给旧页面兜底） */
  process: Object.freeze({
    root: ".video-processing-dialog",
    success: ".video-processing-dialog .vp-footer__title--success",
    failure: ".video-processing-dialog .vp-footer__subtitle--error",
    running: ".video-processing-dialog .vp-footer__progress",
    resultName: ".video-processing-dialog .vp-footer__title--success",
    summary: ".video-processing-dialog .vp-footer__subtitle",
    progressText: ".video-processing-dialog .vp-footer__summary"
  }),
  convert: Object.freeze({
    root: ".progress-card:not(.progress-card--batch)",
    success: ".conversion-progress-download",
    successButton: true,
    failure: ".progress-card__failure",
    resultName: ".progress-card__file",
    progressText: ".progress-card__status"
  })
});
var FAILURE_FALLBACK = {
  queue: "\u5BFC\u51FA\u5931\u8D25\uFF08\u9875\u9762\u672A\u7ED9\u51FA\u539F\u56E0\uFF09",
  process: "\u89C6\u9891\u5904\u7406\u5BFC\u51FA\u5931\u8D25\uFF08\u9875\u9762\u672A\u7ED9\u51FA\u539F\u56E0\uFF09",
  convert: "\u8F6C\u6362\u5931\u8D25\uFF08\u9875\u9762\u672A\u7ED9\u51FA\u539F\u56E0\uFF09"
};
function buildExportStatusExpression(kind) {
  const selectors = EXPORT_STATUS_SELECTORS[kind];
  if (!selectors) throw new Error(`\u672A\u77E5\u5BFC\u51FA\u94FE\u8DEF\uFF1A${kind}`);
  return `(() => {
    const selectors = ${JSON.stringify(selectors)};
    const q = (selector) => document.querySelector(selector);
    const visible = (el) => !!el && el.getClientRects().length > 0;
    const text = (el) => ((el && el.textContent) || '').trim();
    const root = q(selectors.root);
    const successEl = q(selectors.success);
    return {
      rootOpen: visible(root),
      success: selectors.successButton
        ? Boolean(successEl) && !successEl.disabled && visible(successEl)
        : visible(successEl),
      failure: visible(q(selectors.failure)),
      running: selectors.running ? visible(q(selectors.running)) : Boolean(root) && !visible(q(selectors.failure)),
      errorText: text(q(selectors.failure)),
      resultName: text(q(selectors.resultName)),
      summary: selectors.summary ? text(q(selectors.summary)) : '',
      progressText: text(q(selectors.progressText))
    };
  })()`;
}
function classifyExportStatus(kind, snapshot = {}) {
  if (snapshot.failure) {
    return { status: "failed", errorText: snapshot.errorText || FAILURE_FALLBACK[kind] || "\u5BFC\u51FA\u5931\u8D25" };
  }
  if (snapshot.success) {
    return {
      status: "success",
      resultName: snapshot.resultName || null,
      summary: snapshot.summary || null
    };
  }
  return { status: snapshot.running ? "running" : "idle" };
}
function describeExportSnapshot(kind, snapshot = {}) {
  if (!snapshot.rootOpen) {
    if (kind === "queue") return "\u5BFC\u51FA\u961F\u5217\u672A\u51FA\u73B0\uFF08\u4EFB\u52A1\u53EF\u80FD\u6CA1\u6709\u542F\u52A8\uFF09";
    return kind === "process" ? "\u89C6\u9891\u5904\u7406\u5F39\u7A97\u5DF2\u4E0D\u5728\u9875\u9762\u4E0A" : "\u5BFC\u51FA\u8FDB\u5EA6\u5361\u672A\u51FA\u73B0";
  }
  if (snapshot.errorText) return snapshot.errorText;
  if (snapshot.progressText) return snapshot.progressText;
  return "\u9875\u9762\u6CA1\u6709\u7ED9\u51FA\u8FDB\u5EA6\u6216\u9519\u8BEF\u6587\u6848";
}

// src/mp4-info.mjs
var import_promises = require("node:fs/promises");
var BOX_HEADER_SIZE = 8;
var LARGE_BOX_HEADER_SIZE = 16;
function readBoxType(view, offset) {
  return String.fromCharCode(
    view.getUint8(offset),
    view.getUint8(offset + 1),
    view.getUint8(offset + 2),
    view.getUint8(offset + 3)
  );
}
function* iterateBoxes(view, start, end) {
  let offset = start;
  while (offset + BOX_HEADER_SIZE <= end) {
    let size = view.getUint32(offset);
    const type = readBoxType(view, offset + 4);
    let headerSize = BOX_HEADER_SIZE;
    if (size === 1) {
      if (offset + LARGE_BOX_HEADER_SIZE > end) return;
      size = Number(view.getBigUint64(offset + 8));
      headerSize = LARGE_BOX_HEADER_SIZE;
    } else if (size === 0) {
      size = end - offset;
    }
    if (size < headerSize || offset + size > end) return;
    yield { type, contentStart: offset + headerSize, end: offset + size };
    offset += size;
  }
}
function findBox(view, start, end, path2) {
  let from = start;
  let to = end;
  let found = null;
  for (const wanted of path2) {
    let hit = null;
    for (const box of iterateBoxes(view, from, to)) {
      if (box.type === wanted) {
        hit = box;
        break;
      }
    }
    if (!hit) return null;
    found = hit;
    from = hit.contentStart;
    to = hit.end;
  }
  return found;
}
function readTkhdSize(view, box) {
  const version = view.getUint8(box.contentStart);
  const offset = box.contentStart + (version === 1 ? 88 : 76);
  if (offset + 8 > box.end) return null;
  return {
    width: Math.round(view.getUint32(offset) / 65536),
    height: Math.round(view.getUint32(offset + 4) / 65536)
  };
}
function readMdhd(view, box) {
  const version = view.getUint8(box.contentStart);
  const timescaleOffset = box.contentStart + (version === 1 ? 20 : 12);
  if (timescaleOffset + 4 > box.end) return null;
  const timescale = view.getUint32(timescaleOffset);
  if (!timescale) return null;
  let duration = null;
  if (version === 1) {
    if (timescaleOffset + 12 <= box.end) {
      duration = Number(view.getBigUint64(timescaleOffset + 4));
    }
  } else if (timescaleOffset + 8 <= box.end) {
    duration = view.getUint32(timescaleOffset + 4);
  }
  return { timescale, duration };
}
function readSttsStats(view, box) {
  if (box.contentStart + 8 > box.end) return { dominantDelta: null, totalSamples: 0 };
  const entryCount = view.getUint32(box.contentStart + 4);
  const samplesByDelta = /* @__PURE__ */ new Map();
  let totalSamples = 0;
  let offset = box.contentStart + 8;
  for (let i = 0; i < entryCount && offset + 8 <= box.end; i += 1) {
    const sampleCount = view.getUint32(offset);
    const sampleDelta = view.getUint32(offset + 4);
    totalSamples += sampleCount;
    if (sampleDelta > 0) {
      samplesByDelta.set(sampleDelta, (samplesByDelta.get(sampleDelta) ?? 0) + sampleCount);
    }
    offset += 8;
  }
  let dominantDelta = null;
  let best = -1;
  for (const [delta, samples] of samplesByDelta) {
    if (samples > best) {
      best = samples;
      dominantDelta = delta;
    }
  }
  return { dominantDelta, totalSamples };
}
function readMp4InfoFromBuffer(bytes) {
  const empty = { width: null, height: null, fps: null, frames: null, durationSec: null, hasAudio: false };
  try {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let moov = null;
    for (const box of iterateBoxes(view, 0, view.byteLength)) {
      if (box.type === "moov") {
        moov = box;
        break;
      }
    }
    if (!moov) return empty;
    const info = { ...empty };
    for (const trak of iterateBoxes(view, moov.contentStart, moov.end)) {
      if (trak.type !== "trak") continue;
      const hdlr = findBox(view, trak.contentStart, trak.end, ["mdia", "hdlr"]);
      if (!hdlr || hdlr.contentStart + 12 > hdlr.end) continue;
      const handler = readBoxType(view, hdlr.contentStart + 8);
      if (handler === "soun") info.hasAudio = true;
      if (handler !== "vide" || info.frames !== null) continue;
      const tkhd = findBox(view, trak.contentStart, trak.end, ["tkhd"]);
      const mdhd = findBox(view, trak.contentStart, trak.end, ["mdia", "mdhd"]);
      const stts = findBox(view, trak.contentStart, trak.end, ["mdia", "minf", "stbl", "stts"]);
      const size = tkhd ? readTkhdSize(view, tkhd) : null;
      const media = mdhd ? readMdhd(view, mdhd) : null;
      const stats = stts ? readSttsStats(view, stts) : { dominantDelta: null, totalSamples: 0 };
      if (size && size.width > 0 && size.height > 0) {
        info.width = size.width;
        info.height = size.height;
      }
      if (stats.totalSamples > 0) info.frames = stats.totalSamples;
      if (media?.duration && media.timescale) info.durationSec = media.duration / media.timescale;
      if (media && stats.dominantDelta) {
        info.fps = Math.round(media.timescale / stats.dominantDelta * 100) / 100;
      } else if (stats.totalSamples > 0 && info.durationSec) {
        info.fps = Math.round(stats.totalSamples / info.durationSec * 100) / 100;
      }
    }
    return info;
  } catch {
    return empty;
  }
}
async function readMp4Info(filePath) {
  return readMp4InfoFromBuffer(await (0, import_promises.readFile)(filePath));
}

// src/cdp.mjs
var DEFAULT_URL = "https://beta.meewoo.me/";
var DEFAULT_VIEWPORT = { width: 1375, height: 936 };
var DEFAULT_TIMEOUT_MS = 6e5;
var TARGETS = {
  mp4: { label: "\u8F6CMP4", more: false, ext: ".mp4" },
  "dual-mp4": { label: "\u8F6C\u53CC\u901A\u9053MP4", more: false, ext: ".mp4" },
  svga: { label: "\u8F6CSVGA", more: false, ext: ".svga" },
  frames: { label: "\u8F6C\u5E8F\u5217\u5E27", more: true, ext: ".zip" },
  gif: { label: "\u8F6CGIF", more: true, ext: ".gif" },
  webp: { label: "\u8F6Cwebp", more: true, ext: ".webp" }
};
function listTargets() {
  return Object.keys(TARGETS);
}
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function log(message) {
  process.stderr.write(`[meewoo-agent] ${message}
`);
}
async function removeDirWithRetry(dir, { attempts = 20, delayMs = 250 } = {}) {
  for (let i = 0; i < attempts; i += 1) {
    try {
      await (0, import_promises2.rm)(dir, { recursive: true, force: true, maxRetries: 0 });
      return true;
    } catch {
      await sleep(delayMs);
    }
  }
  log(`\u8B66\u544A\uFF1A\u4E34\u65F6\u76EE\u5F55\u6E05\u7406\u5931\u8D25\uFF08\u53EF\u624B\u52A8\u5220\u9664\uFF09\uFF1A${dir}`);
  return false;
}
function chromeCandidates(platform = process.platform, env = process.env) {
  const candidates = [];
  if (env.MEEWOO_CHROME) candidates.push(env.MEEWOO_CHROME);
  if (platform === "win32") {
    const programFiles = env.PROGRAMFILES || "C:\\Program Files";
    const programFilesX86 = env["PROGRAMFILES(X86)"] || "C:\\Program Files (x86)";
    const localAppData = env.LOCALAPPDATA || import_node_path.default.join(import_node_os.default.homedir(), "AppData", "Local");
    candidates.push(
      import_node_path.default.join(programFiles, "Google", "Chrome", "Application", "chrome.exe"),
      import_node_path.default.join(programFilesX86, "Google", "Chrome", "Application", "chrome.exe"),
      import_node_path.default.join(localAppData, "Google", "Chrome", "Application", "chrome.exe"),
      import_node_path.default.join(programFiles, "Microsoft", "Edge", "Application", "msedge.exe"),
      import_node_path.default.join(programFilesX86, "Microsoft", "Edge", "Application", "msedge.exe")
    );
  } else if (platform === "darwin") {
    const home = env.HOME || import_node_os.default.homedir();
    candidates.push(
      "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
      "/Applications/Chromium.app/Contents/MacOS/Chromium",
      "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
      "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
      `${home}/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`,
      `${home}/Applications/Chromium.app/Contents/MacOS/Chromium`
    );
  } else {
    candidates.push(
      "/usr/bin/google-chrome",
      "/usr/bin/google-chrome-stable",
      "/usr/bin/chromium",
      "/usr/bin/chromium-browser",
      "/usr/bin/microsoft-edge"
    );
  }
  return candidates;
}
function findChrome({ platform = process.platform, env = process.env, exists = import_node_fs.existsSync } = {}) {
  return chromeCandidates(platform, env).find((item) => item && exists(item)) || null;
}
async function waitForFile(filePath, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if ((0, import_node_fs.existsSync)(filePath)) return;
    await sleep(100);
  }
  throw new Error(`\u7B49\u5F85\u6587\u4EF6\u8D85\u65F6\uFF1A${filePath}`);
}
function resolveOutputPath(out, artifactName) {
  if (!out) return import_node_path.default.resolve(artifactName);
  const abs = import_node_path.default.resolve(out);
  const endsWithSeparator = /[\\/]$/.test(out);
  const existingDir = (0, import_node_fs.existsSync)(abs) && (0, import_node_fs.statSync)(abs).isDirectory();
  if (endsWithSeparator || existingDir || import_node_path.default.extname(out) === "") {
    return import_node_path.default.join(abs, artifactName);
  }
  return abs;
}
var CdpClient = class {
  constructor(ws, child, userDataDir) {
    this.ws = ws;
    this.child = child;
    this.userDataDir = userDataDir;
    this.nextId = 0;
    this.pending = /* @__PURE__ */ new Map();
    this.sessionId = null;
    this.closed = false;
    ws.on("message", (raw) => {
      let message;
      try {
        message = JSON.parse(String(raw));
      } catch {
        return;
      }
      if (message.id && this.pending.has(message.id)) {
        const { resolve, reject } = this.pending.get(message.id);
        this.pending.delete(message.id);
        if (message.error) reject(new Error(message.error.message || JSON.stringify(message.error)));
        else resolve(message.result || {});
      }
    });
    ws.on("close", () => {
      this.closed = true;
      for (const { reject } of this.pending.values()) reject(new Error("CDP \u8FDE\u63A5\u5DF2\u5173\u95ED"));
      this.pending.clear();
    });
  }
  send(method, params = {}, sessionId = this.sessionId) {
    if (this.closed) return Promise.reject(new Error("CDP \u8FDE\u63A5\u5DF2\u5173\u95ED"));
    const id = ++this.nextId;
    const payload = { id, method, params };
    if (sessionId) payload.sessionId = sessionId;
    this.ws.send(JSON.stringify(payload));
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      setTimeout(() => {
        if (this.pending.has(id)) {
          this.pending.delete(id);
          reject(new Error(`CDP \u8D85\u65F6\uFF1A${method}`));
        }
      }, 15e3);
    });
  }
  async createPage(url = "about:blank") {
    const created = await this.send("Target.createTarget", {
      url,
      newWindow: false
    });
    const attached = await this.send("Target.attachToTarget", { targetId: created.targetId, flatten: true });
    this.sessionId = attached.sessionId;
    await this.send("Page.enable");
    await this.send("Runtime.enable");
    await this.send("DOM.enable");
    await this.send("Emulation.setDeviceMetricsOverride", {
      width: DEFAULT_VIEWPORT.width,
      height: DEFAULT_VIEWPORT.height,
      deviceScaleFactor: 1,
      mobile: false
    });
    return created.targetId;
  }
  async setDownloadBehavior(downloadDir) {
    await this.send("Browser.setDownloadBehavior", {
      behavior: "allow",
      downloadPath: downloadDir,
      eventsEnabled: true
    }, null);
  }
  async evaluate(expression) {
    const result = await this.send("Runtime.evaluate", {
      expression,
      returnByValue: true,
      awaitPromise: true
    });
    if (result.exceptionDetails) {
      const text = result.exceptionDetails.exception?.description || result.exceptionDetails.text || "\u9875\u9762\u811A\u672C\u5F02\u5E38";
      throw new Error(text);
    }
    return result.result?.value;
  }
  async waitFor(expression, timeoutMs = 2e4, intervalMs = 100) {
    const deadline = Date.now() + timeoutMs;
    let lastError = null;
    while (Date.now() < deadline) {
      try {
        if (await this.evaluate(`Boolean(${expression})`)) return true;
      } catch (error) {
        lastError = error;
      }
      await sleep(intervalMs);
    }
    throw new Error(`\u7B49\u5F85\u9875\u9762\u72B6\u6001\u8D85\u65F6\uFF1A${expression}${lastError ? `\uFF08${lastError.message}\uFF09` : ""}`);
  }
  /** 等元素真正可见（v-show 隐藏 / 弹窗未挂载都不算；同名节点有隐藏副本时只认可见的那个） */
  async waitForVisible(selector, timeoutMs = 15e3, intervalMs = 100) {
    const expression = `(() => {
      return [...document.querySelectorAll(${JSON.stringify(selector)})]
        .some((el) => el.getClientRects().length > 0);
    })()`;
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      if (await this.evaluate(expression)) return true;
      await sleep(intervalMs);
    }
    return false;
  }
  async navigate(url) {
    await this.send("Page.navigate", { url });
    await this.waitFor(`document.readyState === 'complete'`, 3e4);
    await this.waitFor(`Boolean(document.querySelector('#app'))`, 3e4);
  }
  async setFileInput(filePath) {
    await this.setFileInputFor("input[type=file]", filePath);
  }
  /** 指定选择器的文件输入（页面可能同时存在导入框 / 替换音频框，不能都点第一个） */
  async setFileInputFor(selector, filePath) {
    const doc = await this.send("DOM.getDocument", { depth: -1, pierce: true });
    const found = await this.send("DOM.querySelector", {
      nodeId: doc.root.nodeId,
      selector
    });
    if (!found.nodeId) throw new Error(`\u9875\u9762\u91CC\u627E\u4E0D\u5230\u6587\u4EF6\u8F93\u5165\u6846\uFF1A${selector}`);
    await this.send("DOM.setFileInputFiles", { nodeId: found.nodeId, files: [import_node_path.default.resolve(filePath)] });
  }
  async click(selector) {
    const clicked = await this.evaluate(`(() => {
      const el = document.querySelector(${JSON.stringify(selector)});
      if (!el) return false;
      el.click();
      return true;
    })()`);
    if (!clicked) throw new Error(`\u627E\u4E0D\u5230\u53EF\u70B9\u51FB\u5143\u7D20\uFF1A${selector}`);
  }
  /** 同 selector 可能有隐藏副本（如编辑器与素材面板都有 data-tip="编辑"），只点可见的那个 */
  async clickVisible(selector) {
    const clicked = await this.evaluate(`(() => {
      const el = [...document.querySelectorAll(${JSON.stringify(selector)})]
        .find((node) => node.getClientRects().length > 0);
      if (!el) return false;
      el.click();
      return true;
    })()`);
    if (!clicked) throw new Error(`\u627E\u4E0D\u5230\u53EF\u70B9\u51FB\u5143\u7D20\uFF1A${selector}`);
  }
  async clickByText(selector, texts) {
    const wanted = JSON.stringify(texts);
    const clicked = await this.evaluate(`(() => {
      const texts = ${wanted};
      const nodes = [...document.querySelectorAll(${JSON.stringify(selector)})];
      const el = nodes.find((node) => texts.includes((node.textContent || '').trim()));
      if (!el) return false;
      el.click();
      return true;
    })()`);
    if (!clicked) throw new Error(`\u627E\u4E0D\u5230\u6309\u94AE\uFF1A${selector} ${texts.join(" / ")}`);
  }
  /** 只点可见的按钮，避免命中已关闭弹窗里残留的同名节点 */
  async clickByTextVisible(selector, texts) {
    const wanted = JSON.stringify(texts);
    const clicked = await this.evaluate(`(() => {
      const texts = ${wanted};
      const el = [...document.querySelectorAll(${JSON.stringify(selector)})]
        .find((node) => node.getClientRects().length > 0 && texts.includes((node.textContent || '').trim()));
      if (!el) return false;
      el.click();
      return true;
    })()`);
    if (!clicked) throw new Error(`\u627E\u4E0D\u5230\u53EF\u89C1\u6309\u94AE\uFF1A${selector} ${texts.join(" / ")}`);
  }
  /** 读底栏状态快照（convert 的进度卡 / process 的视频处理底栏共用一套判定） */
  async readExportStatus(kind) {
    return this.evaluate(buildExportStatusExpression(kind));
  }
  /**
   * 等导出成功 / 失败。失败立即抛错（带页面文案），不再干等满超时。
   * @returns {{ status: 'success', resultName: string|null, summary: string|null, snapshot: object }}
   */
  async waitForExportOutcome(kind, { timeoutMs = DEFAULT_TIMEOUT_MS, actionLabel = "\u5BFC\u51FA" } = {}) {
    const deadline = Date.now() + timeoutMs;
    let lastSnapshot = null;
    let readErrors = 0;
    let lastReadError = null;
    while (Date.now() < deadline) {
      let snapshot2 = null;
      try {
        snapshot2 = await this.readExportStatus(kind);
      } catch (error) {
        lastReadError = error;
        readErrors += 1;
        if (readErrors >= 10) {
          throw new Error(`\u8BFB\u53D6\u5BFC\u51FA\u72B6\u6001\u5931\u8D25\uFF1A${lastReadError.message || String(lastReadError)}`);
        }
      }
      if (snapshot2) {
        readErrors = 0;
        lastSnapshot = snapshot2;
        const state = classifyExportStatus(kind, snapshot2);
        if (state.status === "failed") throw new Error(`${actionLabel}\u5931\u8D25\uFF1A${state.errorText}`);
        if (state.status === "success") {
          return { ...state, snapshot: snapshot2 };
        }
      }
      await sleep(300);
    }
    const snapshot = await this.readExportStatus(kind).catch(() => null) || lastSnapshot || {};
    throw new Error(
      `${actionLabel}\u8D85\u65F6\uFF08${Math.round(timeoutMs / 1e3)}s\uFF09\uFF1A${describeExportSnapshot(kind, snapshot)}`
    );
  }
  /**
   * 等一个「基线之后新增、且名字符合期望」的下载产物。
   * 只扫本次临时下载目录，不碰 `--out`（用户目录里同名旧文件不会串台）。
   */
  async waitForNewArtifact(downloadDir, baseline, { extension: extension2 = "", expectedName = null, namePattern = null } = {}, timeoutMs = 12e4, { actionLabel = "\u7B49\u5F85\u4E0B\u8F7D" } = {}) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const names2 = await (0, import_promises2.readdir)(downloadDir).catch(() => []);
      const picked = selectNewArtifact({ baseline, fileNames: names2, extension: extension2, expectedName, namePattern });
      if (picked) {
        const full = import_node_path.default.join(downloadDir, picked.name);
        const info = await (0, import_promises2.stat)(full).catch(() => null);
        if (info && info.size > 0) {
          return { path: full, name: picked.name, size: info.size, match: picked.match };
        }
      }
      await sleep(300);
    }
    const names = await (0, import_promises2.readdir)(downloadDir).catch(() => []);
    throw new Error(
      `${actionLabel}\u8D85\u65F6\uFF08${Math.round(timeoutMs / 1e3)}s\uFF09\uFF1A\u4E0B\u8F7D\u76EE\u5F55\u91CC\u6CA1\u6709\u51FA\u73B0\u7B26\u5408\u671F\u671B\u7684\u65B0\u6587\u4EF6\uFF08\u671F\u671B ${expectedName || extension2 || "\u4EFB\u610F\u65B0\u6587\u4EF6"}\uFF1B\u5F53\u524D ${names.length ? names.join(", ") : "\u7A7A"}\uFF09`
    );
  }
  async close() {
    try {
      await this.send("Browser.close", {}, null).catch(() => {
      });
    } catch {
    }
    this.closed = true;
    try {
      this.ws.close();
    } catch {
    }
    const child = this.child;
    if (child && child.exitCode === null) {
      await new Promise((resolve) => {
        const timer = setTimeout(resolve, 3e3);
        child.once("exit", () => {
          clearTimeout(timer);
          resolve();
        });
        try {
          if (!child.killed) child.kill();
        } catch {
          clearTimeout(timer);
          resolve();
        }
      });
    }
    if (this.userDataDir) {
      await removeDirWithRetry(this.userDataDir);
    }
  }
};
async function launchChrome({ headless = true } = {}) {
  const chromePath = findChrome();
  if (!chromePath) {
    throw new Error("\u6CA1\u6709\u627E\u5230 Chrome/Chromium\u3002\u8BF7\u5B89\u88C5 Chrome\uFF0C\u6216\u7528 MEEWOO_CHROME \u6307\u5B9A\u53EF\u6267\u884C\u6587\u4EF6\u8DEF\u5F84\u3002");
  }
  const userDataDir = await (0, import_promises2.mkdtemp)(import_node_path.default.join(import_node_os.default.tmpdir(), "meewoo-agent-"));
  let child = null;
  try {
    const args = [
      "--remote-debugging-port=0",
      `--user-data-dir=${userDataDir}`,
      "--no-first-run",
      "--no-default-browser-check",
      "--disable-background-networking",
      "--disable-sync",
      "--disable-extensions",
      `--window-size=${DEFAULT_VIEWPORT.width},${DEFAULT_VIEWPORT.height}`,
      headless ? "--headless=new" : "--start-maximized",
      "about:blank"
    ];
    if (process.platform === "linux") args.unshift("--no-sandbox", "--disable-dev-shm-usage");
    log(`\u542F\u52A8 Chrome\uFF1A${chromePath}`);
    child = (0, import_node_child_process.spawn)(chromePath, args, { stdio: "ignore", windowsHide: true });
    const portFile = import_node_path.default.join(userDataDir, "DevToolsActivePort");
    await waitForFile(portFile, 2e4);
    const [portLine, wsPath] = (await (0, import_promises2.readFile)(portFile, "utf8")).trim().split(/\r?\n/);
    const port = Number(portLine);
    if (!port) throw new Error("Chrome \u6CA1\u6709\u8FD4\u56DE DevTools \u7AEF\u53E3");
    const ws = new wrapper_default(`ws://127.0.0.1:${port}${wsPath || "/devtools/browser"}`);
    await new Promise((resolve, reject) => {
      ws.once("open", resolve);
      ws.once("error", reject);
    });
    return new CdpClient(ws, child, userDataDir);
  } catch (error) {
    try {
      if (child && child.exitCode === null) child.kill();
    } catch {
    }
    await removeDirWithRetry(userDataDir, { attempts: 8, delayMs: 200 });
    throw error;
  }
}
function resolveHeadless(headed) {
  return !(typeof headed === "boolean" ? headed : process.env.MEEWOO_HEADED === "1");
}
async function readSourceInfo(client) {
  return client.evaluate(`(() => ({
    format: document.querySelector('.source-info-bar-format')?.textContent?.trim() || null,
    fileName: document.querySelector('.source-info-bar-name')?.textContent?.trim() || null,
    facts: [...document.querySelectorAll('.source-info-bar-fact')].map((el) => {
      const label = el.querySelector('.source-info-bar-label')?.textContent?.trim() || '';
      const value = el.querySelector('.source-info-bar-value')?.textContent?.trim() || '';
      return { label, value };
    }),
    title: document.title
  }))()`);
}
async function probeFile(input, { url = DEFAULT_URL, timeoutMs = 6e4, headed } = {}) {
  const abs = import_node_path.default.resolve(input);
  if (!(0, import_node_fs.existsSync)(abs)) throw new Error(`\u6587\u4EF6\u4E0D\u5B58\u5728\uFF1A${abs}`);
  const client = await launchChrome({ headless: resolveHeadless(headed) });
  try {
    await client.createPage("about:blank");
    await client.navigate(url);
    await client.waitFor(`Boolean(document.querySelector('.empty-state'))`, 3e4);
    await client.setFileInput(abs);
    await client.waitFor(`Boolean(document.querySelector('.source-info-bar-format'))`, timeoutMs);
    await sleep(500);
    return await readSourceInfo(client);
  } finally {
    await client.close();
  }
}
async function convertFile(input, target, { out, url = DEFAULT_URL, timeoutMs = DEFAULT_TIMEOUT_MS, headed } = {}) {
  const targetConfig = TARGETS[target];
  if (!targetConfig) throw new Error(`\u4E0D\u652F\u6301\u7684\u76EE\u6807\uFF1A${target}\uFF1B\u53EF\u7528\uFF1A${Object.keys(TARGETS).join(", ")}`);
  const abs = import_node_path.default.resolve(input);
  if (!(0, import_node_fs.existsSync)(abs)) throw new Error(`\u6587\u4EF6\u4E0D\u5B58\u5728\uFF1A${abs}`);
  const downloadDir = await (0, import_promises2.mkdtemp)(import_node_path.default.join(import_node_os.default.tmpdir(), "meewoo-agent-dl-"));
  const client = await launchChrome({ headless: resolveHeadless(headed) });
  try {
    await client.setDownloadBehavior(downloadDir);
    await client.createPage("about:blank");
    await client.navigate(url);
    await client.waitFor(`Boolean(document.querySelector('.empty-state'))`, 3e4);
    await client.setFileInput(abs);
    await client.waitFor(`Boolean(document.querySelector('.source-info-bar-format'))`, timeoutMs);
    await sleep(500);
    if (targetConfig.more) {
      await client.waitFor(`Boolean(document.querySelector('.edit-bar-more-trigger'))`, 15e3);
      await client.click(".edit-bar-more-trigger");
      await client.waitFor(`Boolean(document.querySelector('.edit-bar-more-menu.is-open'))`, 5e3);
      await client.clickByText(".edit-bar-more-btn", [targetConfig.label]);
    } else {
      await client.waitFor(`Boolean(document.querySelector('.edit-bar-export-btn'))`, 15e3);
      await client.clickByText(".edit-bar-export-btn", [targetConfig.label]);
    }
    await client.waitFor(`Boolean(document.querySelector('.export-popup.is-visible'))`, 15e3);
    await sleep(300);
    const baseline = createDownloadBaseline(await (0, import_promises2.readdir)(downloadDir).catch(() => []));
    await client.clickByTextVisible(".export-popup button", ["\u786E\u8BA4\u5BFC\u51FA", "\u5F00\u59CB\u5BFC\u51FA"]);
    const confirmOpened = await client.waitForVisible(".export-confirm", 5e3);
    if (confirmOpened) {
      await client.clickByTextVisible(".export-confirm button", ["\u786E\u8BA4\u5BFC\u51FA", "\u5F00\u59CB\u5BFC\u51FA"]);
    }
    log(`\u5DF2\u5F00\u59CB\u5BFC\u51FA\uFF08${target}\uFF09\uFF0C\u7B49\u5F85\u4EFB\u52A1\u5B8C\u6210\u2026`);
    const outcome = await client.waitForExportOutcome("convert", { timeoutMs, actionLabel: "\u683C\u5F0F\u8F6C\u6362" });
    await client.clickVisible(".conversion-progress-download");
    const artifact = await client.waitForNewArtifact(
      downloadDir,
      baseline,
      { extension: targetConfig.ext, expectedName: outcome.resultName || null },
      Math.min(timeoutMs, 12e4),
      { actionLabel: "\u7B49\u5F85\u4EA7\u7269\u4E0B\u8F7D" }
    );
    const outputPath = resolveOutputPath(out, artifact.name);
    await (0, import_promises2.mkdir)(import_node_path.default.dirname(outputPath), { recursive: true });
    await (0, import_promises2.copyFile)(artifact.path, outputPath);
    const info = await (0, import_promises2.stat)(outputPath);
    return { file: outputPath, bytes: info.size, target, fileName: import_node_path.default.basename(outputPath) };
  } finally {
    await client.close();
    await (0, import_promises2.rm)(downloadDir, { recursive: true, force: true }).catch(() => {
    });
  }
}
var PROCESS_MODULES = Object.freeze({ picture: "\u753B\u9762", audio: "\u58F0\u97F3", export: "\u5BFC\u51FA" });
function resolvePageFadeMaxSec(durationSec) {
  if (!Number.isFinite(durationSec) || durationSec <= 0) return null;
  return Math.floor(Math.min(5, durationSec / 2) * 10) / 10;
}
function readSourceDurationSec(source) {
  const fact = (source?.facts || []).find((item) => String(item.label || "").includes("\u65F6\u957F"));
  const match = String(fact?.value || "").match(/(\d+(?:\.\d+)?)/);
  return match ? Number(match[1]) : null;
}
function clampFadeSec(value, pageMaxSec, label) {
  if (value === null || value === void 0) return null;
  if (pageMaxSec === null || value <= pageMaxSec) return value;
  log(`\u8B66\u544A\uFF1A${label} ${value}s \u8D85\u8FC7\u9875\u9762\u4E0A\u9650 ${pageMaxSec}s\uFF08\u7D20\u6750\u65F6\u957F\u4E00\u534A\uFF09\uFF0C\u6309 ${pageMaxSec}s \u5BFC\u51FA`);
  return pageMaxSec;
}
async function selectProcessingModule(client, label) {
  await client.clickByTextVisible(".processing-rail__item", [label]);
  await client.waitFor(
    `(() => {
      const el = [...document.querySelectorAll('.processing-rail__item')]
        .find((node) => node.getClientRects().length > 0 && (node.textContent || '').trim() === ${JSON.stringify(label)});
      return !!el && el.classList.contains('is-active');
    })()`,
    5e3
  );
}
async function setSwitchState(client, selector, enabled, label) {
  const current = await client.evaluate(`(() => {
    const el = [...document.querySelectorAll(${JSON.stringify(selector)})]
      .find((node) => node.getClientRects().length > 0);
    return el ? el.getAttribute('aria-checked') : null;
  })()`);
  if (current === null) throw new Error(`\u627E\u4E0D\u5230\u300C${label}\u300D\u5F00\u5173\uFF1A${selector}`);
  if (current === "true" === enabled) return;
  await client.clickVisible(selector);
  await client.waitFor(
    `(() => {
      const el = [...document.querySelectorAll(${JSON.stringify(selector)})]
        .find((node) => node.getClientRects().length > 0);
      return !!el && el.getAttribute('aria-checked') === ${JSON.stringify(String(enabled))};
    })()`,
    5e3
  );
}
async function setNumberInputValue(client, selector, index, value, label) {
  const text = String(value);
  const found = await client.evaluate(`(() => {
    const el = [...document.querySelectorAll(${JSON.stringify(selector)})]
      .filter((node) => node.getClientRects().length > 0)[${index}];
    if (!el || el.disabled) return false;
    el.focus();
    el.value = ${JSON.stringify(text)};
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('blur'));
    return true;
  })()`);
  if (!found) throw new Error(`\u627E\u4E0D\u5230\uFF08\u6216\u4E0D\u53EF\u7F16\u8F91\uFF09\u300C${label}\u300D\u8F93\u5165\u6846\uFF1A${selector}`);
  await sleep(80);
  const actual = await client.evaluate(`(() => {
    const el = [...document.querySelectorAll(${JSON.stringify(selector)})]
      .filter((node) => node.getClientRects().length > 0)[${index}];
    return el ? el.value : null;
  })()`);
  if (actual === null || actual === "" || Number.parseFloat(actual) !== Number(value)) {
    throw new Error(`\u300C${label}\u300D\u6CA1\u6709\u5199\u5165\u9884\u671F\u503C ${value}\uFF08\u9875\u9762\u663E\u793A ${actual}\uFF09`);
  }
}
async function applyProcessingEffects(client, effects, { durationSec } = {}) {
  if (!effects) return;
  const pageMax = resolvePageFadeMaxSec(durationSec);
  await selectProcessingModule(client, PROCESS_MODULES.picture);
  if (effects.fade) {
    await setSwitchState(client, '[aria-label="\u542F\u7528\u753B\u9762\u6DE1\u5165\u6DE1\u51FA"]', effects.fade.enabled, "\u542F\u7528\u753B\u9762\u6DE1\u5165\u6DE1\u51FA");
    if (effects.fade.enabled) {
      const fadeIn = clampFadeSec(effects.fade.in, pageMax, "\u753B\u9762\u6DE1\u5165");
      const fadeOut = clampFadeSec(effects.fade.out, pageMax, "\u753B\u9762\u6DE1\u51FA");
      if (fadeIn !== null) {
        await setNumberInputValue(client, ".picture-module .fade-field__value input", 0, fadeIn, "\u753B\u9762\u6DE1\u5165");
      }
      if (fadeOut !== null) {
        await setNumberInputValue(client, ".picture-module .fade-field__value input", 1, fadeOut, "\u753B\u9762\u6DE1\u51FA");
      }
    }
  }
  if (effects.edge) {
    await setSwitchState(client, '[aria-label="\u542F\u7528\u4E0A\u4E0B\u6E10\u9690"]', effects.edge.enabled, "\u542F\u7528\u4E0A\u4E0B\u6E10\u9690");
    if (effects.edge.enabled) {
      if (effects.edge.top !== null) {
        await setNumberInputValue(client, ".edge-fade-field .fade-field__value input", 0, effects.edge.top, "\u4E0A\u8FB9\u7F18\u6E10\u9690");
      }
      if (effects.edge.bottom !== null) {
        await setNumberInputValue(client, ".edge-fade-field .fade-field__value input", 1, effects.edge.bottom, "\u4E0B\u8FB9\u7F18\u6E10\u9690");
      }
    }
  }
  if (!effects.audio) return;
  await selectProcessingModule(client, PROCESS_MODULES.audio);
  if (effects.audio.volume !== null) {
    await setNumberInputValue(
      client,
      ".audio-module__volume-value input",
      0,
      Math.round(effects.audio.volume * 100),
      "\u5BFC\u51FA\u97F3\u91CF"
    );
  }
  if (effects.audio.fade) {
    await setSwitchState(client, '[aria-label="\u542F\u7528\u58F0\u97F3\u6DE1\u5165\u6DE1\u51FA"]', effects.audio.fade.enabled, "\u542F\u7528\u58F0\u97F3\u6DE1\u5165\u6DE1\u51FA");
    if (effects.audio.fade.enabled) {
      const fadeIn = clampFadeSec(effects.audio.fade.in, pageMax, "\u97F3\u9891\u6DE1\u5165");
      const fadeOut = clampFadeSec(effects.audio.fade.out, pageMax, "\u97F3\u9891\u6DE1\u51FA");
      if (fadeIn !== null) {
        await setNumberInputValue(client, ".audio-module .fade-field__value input", 0, fadeIn, "\u97F3\u9891\u6DE1\u5165");
      }
      if (fadeOut !== null) {
        await setNumberInputValue(client, ".audio-module .fade-field__value input", 1, fadeOut, "\u97F3\u9891\u6DE1\u51FA");
      }
    }
  }
}
async function setReplacementAudio(client, filePath) {
  const fileName = import_node_path.default.basename(filePath);
  await selectProcessingModule(client, PROCESS_MODULES.audio);
  await client.setFileInputFor(".audio-module input[type=file]", filePath);
  const deadline = Date.now() + 15e3;
  while (Date.now() < deadline) {
    const snapshot = await client.evaluate(`(() => ({
      name: document.querySelector('.audio-module__file-name')?.textContent?.trim() || '',
      error: document.querySelector('.audio-module__error')?.textContent?.trim() || ''
    }))()`);
    if (snapshot.error) throw new Error(`\u66FF\u6362\u97F3\u9891\u5931\u8D25\uFF1A${snapshot.error}`);
    if (snapshot.name === fileName) return;
    await sleep(100);
  }
  throw new Error(`\u66FF\u6362\u97F3\u9891\u6CA1\u6709\u88AB\u9875\u9762\u63A5\u6536\uFF1A${fileName}\uFF08\u8BF7\u786E\u8BA4\u662F MP3 / WAV / M4A / AAC\uFF09`);
}
async function selectProcessingTarget(client, target) {
  const config = PROCESS_TARGETS[target];
  await selectProcessingModule(client, PROCESS_MODULES.export);
  await client.clickVisible(".export-module .select__trigger");
  await client.waitFor(
    `Boolean(document.querySelector('.export-module .select__option[data-value=${JSON.stringify(target)}]'))`,
    5e3
  );
  await client.clickVisible(`.export-module .select__option[data-value=${JSON.stringify(target)}]`);
  await client.waitFor(
    `(() => {
      const el = document.querySelector('.export-module .select__value');
      return !!el && (el.textContent || '').trim() === ${JSON.stringify(config.label)};
    })()`,
    5e3
  );
}
async function readProcessingFooterSummary(client) {
  return client.evaluate(`(() => {
    const el = document.querySelector('.video-processing-dialog .vp-footer__subtitle');
    return el ? (el.textContent || '').trim() : null;
  })()`);
}
async function openProcessingDialog(client) {
  if (!await client.waitForVisible(".edit-bar-export-btn", 15e3)) {
    throw new Error("\u6CA1\u6709\u627E\u5230\u5BFC\u51FA\u6309\u94AE\uFF1A\u9875\u9762\u8FD8\u6CA1\u52A0\u8F7D\u5B8C\uFF0C\u6216\u9009\u4E2D\u7D20\u6750\u4E0D\u662F MP4");
  }
  await client.clickByTextVisible(".edit-bar-export-btn", ["\u8F6C\u53CC\u901A\u9053MP4"]);
  if (!await client.waitForVisible(".export-popup.is-visible", 15e3)) {
    throw new Error("\u300C\u8F6C\u53CC\u901A\u9053MP4\u300D\u5BFC\u51FA\u9762\u677F\u6CA1\u6709\u6253\u5F00");
  }
  await sleep(300);
  if (await client.waitForVisible(".export-popup .popup-button-light", 3e3)) {
    await client.clickVisible(".export-popup .popup-button-light");
  } else {
    await client.clickByTextVisible(".export-popup button", ["\u53D6\u6D88"]);
    await sleep(300);
    if (!await client.waitForVisible('[data-tip="\u7F16\u8F91"]', 5e3)) {
      throw new Error("\u627E\u4E0D\u5230\u89C6\u9891\u5904\u7406\u5165\u53E3\uFF1A\u9875\u9762\u9700\u8981 2026-11-01 \u4E4B\u540E\u7684\u7248\u672C\uFF08\u5BFC\u51FA\u9762\u677F\u5E95\u90E8\u300C\u8C03\u6574\u5BFC\u51FA\u300D\uFF09");
    }
    await client.clickVisible('[data-tip="\u7F16\u8F91"]');
  }
  if (!await client.waitForVisible(".video-processing-dialog", 15e3)) {
    throw new Error("\u89C6\u9891\u5904\u7406\u5F39\u7A97\u6CA1\u6709\u6253\u5F00");
  }
  await client.waitFor(`Boolean(document.querySelector('.processing-rail__item'))`, 1e4);
}
async function waitForExportStarted(client, timeoutMs = 3e4) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const snapshot = await client.evaluate(`(() => ({
      error: document.querySelector('.video-processing-dialog .vp-footer__subtitle--error')?.textContent?.trim() || '',
      dialogOpen: !!document.querySelector('.video-processing-dialog'),
      confirmOpen: !!document.querySelector('.export-confirm')
    }))()`);
    if (snapshot.error) throw new Error(`\u89C6\u9891\u5904\u7406\u5BFC\u51FA\u542F\u52A8\u5931\u8D25\uFF1A${snapshot.error}`);
    if (!snapshot.dialogOpen && !snapshot.confirmOpen) {
      if (!await client.waitForVisible(".export-queue", 2e4)) {
        throw new Error("\u5BFC\u51FA\u4EFB\u52A1\u6CA1\u6709\u8FDB\u5165\u53F3\u4E0A\u89D2\u5BFC\u51FA\u961F\u5217");
      }
      return;
    }
    await sleep(200);
  }
  throw new Error("\u786E\u8BA4\u5BFC\u51FA\u540E\u89C6\u9891\u5904\u7406\u5F39\u7A97\u6CA1\u6709\u5173\u95ED\uFF08\u4EFB\u52A1\u53EF\u80FD\u6CA1\u6709\u542F\u52A8\uFF09");
}
async function confirmProcessingExport(client, { preset }) {
  const selector = preset ? ".vp-footer__actions .ui-button--recommend" : ".vp-footer__actions .ui-button--primary";
  if (!await client.waitForVisible(selector, 1e4)) {
    throw new Error("\u89C6\u9891\u5904\u7406\u5F39\u7A97\u7684\u5BFC\u51FA\u6309\u94AE\u4E0D\u53EF\u7528");
  }
  await client.clickVisible(selector);
  if (!await client.waitForVisible(".export-confirm", 15e3)) {
    throw new Error("\u786E\u8BA4\u5BFC\u51FA\u53C2\u6570\u5F39\u7A97\u6CA1\u6709\u51FA\u73B0");
  }
  await client.clickByTextVisible(".export-confirm button", ["\u786E\u8BA4\u5BFC\u51FA"]);
  await waitForExportStarted(client);
}
async function processFile(input, {
  preset,
  effects,
  target,
  replacement,
  out,
  url = DEFAULT_URL,
  timeoutMs = DEFAULT_TIMEOUT_MS,
  headed
} = {}) {
  const plan = resolveProcessPlan({ preset, effects, target, replacement });
  const targetConfig = PROCESS_TARGETS[plan.target];
  const replacementPath = plan.replacement ? import_node_path.default.resolve(plan.replacement) : null;
  if (replacementPath) {
    assertReplacementAudioExtension(replacementPath);
    if (!(0, import_node_fs.existsSync)(replacementPath)) throw new Error(`\u66FF\u6362\u97F3\u9891\u4E0D\u5B58\u5728\uFF1A${replacementPath}`);
  }
  const abs = import_node_path.default.resolve(input);
  if (!(0, import_node_fs.existsSync)(abs)) throw new Error(`\u6587\u4EF6\u4E0D\u5B58\u5728\uFF1A${abs}`);
  if (import_node_path.default.extname(abs).toLowerCase() !== ".mp4") {
    throw new Error(`process \u53EA\u652F\u6301 mp4 \u6E90\uFF1A${import_node_path.default.basename(abs)} \u4E0D\u662F .mp4\uFF08\u89C6\u9891\u5904\u7406\u5165\u53E3\u53EA\u5BF9 MP4 \u5F00\u653E\uFF09`);
  }
  const downloadDir = await (0, import_promises2.mkdtemp)(import_node_path.default.join(import_node_os.default.tmpdir(), "meewoo-agent-dl-"));
  const client = await launchChrome({ headless: resolveHeadless(headed) });
  try {
    await client.setDownloadBehavior(downloadDir);
    await client.createPage("about:blank");
    try {
      await client.navigate(url);
    } catch (error) {
      throw new Error(`\u9875\u9762\u52A0\u8F7D\u5931\u8D25\uFF1A${url}\uFF08${error.message}\uFF09`);
    }
    try {
      await client.waitFor(`Boolean(document.querySelector('.empty-state'))`, 3e4);
    } catch (error) {
      throw new Error(`\u9875\u9762\u672A\u5C31\u7EEA\uFF1A${url}\uFF08${error.message}\uFF09`);
    }
    let source;
    try {
      await client.setFileInput(abs);
      await client.waitFor(`Boolean(document.querySelector('.source-info-bar-format'))`, timeoutMs);
      await sleep(500);
      source = await readSourceInfo(client);
    } catch (error) {
      throw new Error(`\u5BFC\u5165\u5931\u8D25\uFF1A${error.message}`);
    }
    const formatLabel = String(source?.format || "").trim();
    if (formatLabel.toUpperCase() !== "MP4") {
      throw new Error(
        `process \u53EA\u652F\u6301 mp4 \u6E90\uFF1A\u9875\u9762\u8BC6\u522B\u4E3A\u300C${formatLabel || "\u672A\u77E5"}\u300D\uFF08\u89C6\u9891\u5904\u7406\u5165\u53E3\u53EA\u5BF9 MP4 \u5F00\u653E\uFF09`
      );
    }
    await openProcessingDialog(client);
    let summary = null;
    if (plan.mode === "custom") {
      await applyProcessingEffects(client, plan.effects, { durationSec: readSourceDurationSec(source) });
    }
    if (replacementPath) {
      await setReplacementAudio(client, replacementPath);
    }
    if (plan.mode === "custom" && plan.effects?.audio) {
      await setSwitchState(client, '[aria-label="\u542F\u7528\u97F3\u9891"]', plan.effects.audio.enabled, "\u542F\u7528\u97F3\u9891");
    }
    if (plan.mode === "custom") {
      await selectProcessingTarget(client, plan.target);
      summary = await readProcessingFooterSummary(client);
    }
    await confirmProcessingExport(client, { preset: plan.mode === "preset" });
    log(`\u5DF2\u5F00\u59CB\u89C6\u9891\u5904\u7406\u5BFC\u51FA\uFF08${plan.target}\uFF09\uFF0C\u7B49\u5F85\u4EFB\u52A1\u5B8C\u6210\u2026`);
    const outcome = await client.waitForExportOutcome("queue", { timeoutMs, actionLabel: "\u89C6\u9891\u5904\u7406\u5BFC\u51FA" });
    const baseline = createDownloadBaseline(await (0, import_promises2.readdir)(downloadDir).catch(() => []));
    await client.clickVisible(".export-queue .conversion-progress-download");
    const artifact = await client.waitForNewArtifact(
      downloadDir,
      baseline,
      {
        extension: targetConfig.extension,
        expectedName: outcome.resultName || expectedProcessedName(import_node_path.default.basename(abs), targetConfig.extension),
        namePattern: targetConfig.namePattern
      },
      Math.min(timeoutMs, 12e4),
      { actionLabel: "\u7B49\u5F85\u4EA7\u7269\u4E0B\u8F7D" }
    );
    const outputPath = resolveOutputPath(out, artifact.name);
    await (0, import_promises2.mkdir)(import_node_path.default.dirname(outputPath), { recursive: true });
    await (0, import_promises2.copyFile)(artifact.path, outputPath);
    const info = await (0, import_promises2.stat)(outputPath);
    const mp4 = targetConfig.extension === ".mp4" ? await readMp4Info(outputPath).catch(() => null) : null;
    if (targetConfig.extension === ".mp4" && (!mp4 || mp4.width === null || mp4.height === null)) {
      log("\u8B66\u544A\uFF1A\u65E0\u6CD5\u4ECE\u4EA7\u7269\u8BFB\u53D6\u5BBD\u9AD8 / \u5E27\u6570\uFF0C\u8FD4\u56DE null\uFF08\u4E0D\u7F16\u9020\u8BFB\u6570\uFF09");
    }
    return {
      file: outputPath,
      bytes: info.size,
      target: plan.target,
      fileName: import_node_path.default.basename(outputPath),
      width: mp4?.width ?? null,
      height: mp4?.height ?? null,
      fps: mp4?.fps ?? null,
      frames: mp4?.frames ?? null,
      summary
    };
  } finally {
    await client.close();
    await (0, import_promises2.rm)(downloadDir, { recursive: true, force: true }).catch(() => {
    });
  }
}

// meewoo-agent.mjs
var VERSION = "1.5.0.0";
function usage() {
  return `MeeWoo Agent ${VERSION}

\u7528\u6CD5\uFF1A
  meewoo probe <file> [--headed] [--url <url>]
  meewoo convert <file> --target <${listTargets().join("|")}> [--out <path>] [--headed] [--url <url>]
  meewoo process <file> --preset <${PROCESS_PRESET_NAMES.join("|")}> [--out <path>] [--timeout <seconds>] [--headed] [--url <url>]
  meewoo process <file> [--effects <json>] [--target <${PROCESS_TARGET_NAMES.join("|")}>] [--replacement <audio>] [--out <path>] [--timeout <seconds>] [--headed] [--url <url>]
  meewoo doctor
  meewoo mcp

\u8BF4\u660E\uFF1A
  - probe / convert / process \u662F\u4E09\u6761\u94FE\u8DEF\uFF1Aprobe \u53EA\u8BFB\uFF0Cconvert \u8D70\u5E95\u680F\u5BFC\u51FA\u5F39\u7A97\uFF0Cprocess \u8D70\u300C\u8F6C\u53CC\u901A\u9053MP4 \u2192 \u8C03\u6574\u5BFC\u51FA\u300D\u7684\u89C6\u9891\u5904\u7406\u5F39\u7A97
  - process \u53EA\u652F\u6301 mp4 \u6E90\uFF1B--preset \u4E0E --effects / --target / --replacement \u4E92\u65A5
  - \u4E0D\u4F20 --preset \u65F6\u81F3\u5C11\u7ED9\u4E00\u4E2A\u81EA\u5B9A\u4E49\u53C2\u6570\uFF1B--target \u7F3A\u7701 dual-mp4
  - --effects \u5F62\u72B6\uFF1A{"fade":{"enabled":true,"in":0.5,"out":0.5},"edge":{"enabled":true,"top":8,"bottom":8},"audio":{"enabled":true,"volume":0.8,"fade":{"enabled":true,"in":1,"out":1}}}
    volume \u662F 0\u20131\uFF1B\u4E5F\u63A5\u53D7 volumePercent 0\u2013100\u3002\u66FF\u6362\u97F3\u9891\u5355\u72EC\u7528 --replacement\uFF08mp3/wav/m4a/aac\uFF09
  - \u8FD4\u56DE { file, bytes, target, fileName, width, height, fps, frames, summary }\uFF1BSVGA \u7684\u5BBD\u9AD8/\u5E27\u7387\u4E3A null
  - \u672C\u673A\u9700\u8981 Chrome/Chromium\uFF08\u6216\u7528 MEEWOO_CHROME \u6307\u5B9A\u8DEF\u5F84\uFF09
  - Windows / macOS / Linux \u5747\u53EF\uFF1B\u4E0D\u4F9D\u8D56 Playwright
  - \u9ED8\u8BA4\u65E0\u5934 Chrome\uFF1B\u53EA\u6709\u663E\u5F0F --headed\uFF08\u6216 MEEWOO_HEADED=1\uFF09\u624D\u5F00\u7A97\u53E3
  - \u9ED8\u8BA4\u4F7F\u7528 ${DEFAULT_URL}\uFF1B\u53EF\u7528 --url \u6307\u5411\u672C\u5730 docs \u670D\u52A1
  - \u5BFC\u51FA\u7B49\u5F85\u9ED8\u8BA4 ${DEFAULT_TIMEOUT_MS / 1e3}s\uFF0C\u53EF\u7528 --timeout \u8C03\u6574\uFF08\u79D2\uFF09
`;
}
function runDoctor() {
  const chrome = findChrome();
  const info = {
    platform: process.platform,
    arch: process.arch,
    node: process.version,
    chrome,
    ok: Boolean(chrome)
  };
  process.stdout.write(`${JSON.stringify(info, null, 2)}
`);
  if (!chrome) process.exitCode = 1;
}
function parseArgs(argv) {
  const positional = [];
  const flags = {};
  const booleanFlags = /* @__PURE__ */ new Set(["headed"]);
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg.startsWith("--")) {
      const key = arg.slice(2);
      if (booleanFlags.has(key)) {
        flags[key] = true;
        continue;
      }
      const next = argv[i + 1];
      if (next && !next.startsWith("--")) {
        flags[key] = next;
        i += 1;
      } else {
        flags[key] = true;
      }
    } else {
      positional.push(arg);
    }
  }
  return { positional, flags };
}
async function runProbe(argv) {
  const { positional, flags } = parseArgs(argv);
  const input = positional[0];
  if (!input) throw new Error("probe \u9700\u8981\u4E00\u4E2A\u6587\u4EF6\u8DEF\u5F84");
  const result = await probeFile(input, {
    url: flags.url || DEFAULT_URL,
    headed: flags.headed === true ? true : void 0
  });
  process.stdout.write(`${JSON.stringify(result, null, 2)}
`);
}
async function runConvert(argv) {
  const { positional, flags } = parseArgs(argv);
  const input = positional[0];
  if (!input) throw new Error("convert \u9700\u8981\u4E00\u4E2A\u6587\u4EF6\u8DEF\u5F84");
  if (!flags.target) throw new Error(`convert \u9700\u8981 --target\uFF08${listTargets().join(" / ")}\uFF09`);
  const result = await convertFile(input, String(flags.target), {
    out: flags.out ? String(flags.out) : void 0,
    url: flags.url || DEFAULT_URL,
    headed: flags.headed === true ? true : void 0
  });
  process.stdout.write(`${JSON.stringify(result, null, 2)}
`);
}
function resolveTimeoutMs(value) {
  if (value === void 0 || value === null) return DEFAULT_TIMEOUT_MS;
  if (typeof value === "boolean") throw new Error("\u8D85\u65F6\u65F6\u95F4\u9700\u8981\u4E00\u4E2A\u6B63\u6570");
  const ms = Number(value);
  if (!Number.isFinite(ms) || ms <= 0) throw new Error(`\u8D85\u65F6\u65F6\u95F4\u9700\u8981\u6B63\u6570\uFF1A${value}`);
  return Math.round(ms);
}
var PROCESS_FLAGS = /* @__PURE__ */ new Set(["preset", "effects", "target", "replacement", "out", "url", "headed", "timeout"]);
async function runProcess(argv) {
  const { positional, flags } = parseArgs(argv);
  const input = positional[0];
  if (!input) throw new Error("process \u9700\u8981\u4E00\u4E2A mp4 \u6587\u4EF6\u8DEF\u5F84");
  const unknown = Object.keys(flags).filter((key) => !PROCESS_FLAGS.has(key));
  if (unknown.length) throw new Error(`\u672A\u77E5\u53C2\u6570\uFF1A${unknown.map((key) => `--${key}`).join(", ")}`);
  for (const key of ["preset", "effects", "target", "replacement", "out", "url", "timeout"]) {
    if (flags[key] === true) throw new Error(`--${key} \u9700\u8981\u4E00\u4E2A\u503C`);
  }
  resolveProcessPlan({
    preset: flags.preset,
    effects: flags.effects,
    target: flags.target,
    replacement: flags.replacement
  });
  const timeoutMs = resolveTimeoutMs(flags.timeout === void 0 ? void 0 : Number(flags.timeout) * 1e3);
  const result = await processFile(input, {
    preset: flags.preset,
    effects: flags.effects,
    target: flags.target,
    replacement: flags.replacement,
    out: flags.out ? String(flags.out) : void 0,
    url: flags.url || DEFAULT_URL,
    timeoutMs,
    headed: flags.headed === true ? true : void 0
  });
  process.stdout.write(`${JSON.stringify(result, null, 2)}
`);
}
var EFFECTS_SCHEMA = {
  type: "object",
  description: "\u81EA\u5B9A\u4E49\u6548\u679C\uFF1B\u53EA\u4F20\u60F3\u6539\u7684\u6BB5\u3002fade/edge/audio \u51FA\u73B0\u4F46\u6CA1\u5199 enabled \u65F6\u89C6\u4E3A true\u3002",
  properties: {
    fade: {
      type: "object",
      description: "\u753B\u9762\u6DE1\u5165\u6DE1\u51FA\uFF08\u79D2\uFF0C0\u20135\uFF1B\u9875\u9762\u6309\u7D20\u6750\u65F6\u957F\u4E00\u534A\u6536\u655B\uFF09",
      properties: {
        enabled: { type: "boolean" },
        in: { type: "number", minimum: 0, maximum: 5 },
        out: { type: "number", minimum: 0, maximum: 5 }
      },
      additionalProperties: false
    },
    edge: {
      type: "object",
      description: "\u4E0A\u4E0B\u6E10\u9690\uFF08\u89C6\u9891\u9AD8\u5EA6\u767E\u5206\u6BD4\uFF0C\u5355\u8FB9 0\u201350\uFF09",
      properties: {
        enabled: { type: "boolean" },
        top: { type: "number", minimum: 0, maximum: 50 },
        bottom: { type: "number", minimum: 0, maximum: 50 }
      },
      additionalProperties: false
    },
    audio: {
      type: "object",
      description: "\u97F3\u91CF\u4E0E\u97F3\u91CF\u6DE1\u5165\u6DE1\u51FA\uFF1Bvolume 0\u20131\uFF0C\u6216\u6539\u7528 volumePercent 0\u2013100\uFF08\u4E8C\u9009\u4E00\uFF09",
      properties: {
        enabled: { type: "boolean", description: "false = \u5BFC\u51FA\u65E0\u58F0" },
        volume: { type: "number", minimum: 0, maximum: 1 },
        volumePercent: { type: "number", minimum: 0, maximum: 100 },
        fade: {
          type: "object",
          properties: {
            enabled: { type: "boolean" },
            in: { type: "number", minimum: 0, maximum: 5 },
            out: { type: "number", minimum: 0, maximum: 5 }
          },
          additionalProperties: false
        }
      },
      additionalProperties: false
    }
  },
  additionalProperties: false
};
function toolDefinitions() {
  return [
    {
      name: "probe",
      description: "\u8BFB\u53D6\u672C\u5730\u52A8\u753B\u6587\u4EF6\u7684\u683C\u5F0F\u3001\u5185\u5BB9\u5C3A\u5BF8\u3001\u5E27\u7387\u3001\u65F6\u957F\u4E0E\u603B\u5E27\u6570\uFF08MeeWoo \u672C\u5730 CDP \u6865\uFF09\u3002\u9ED8\u8BA4\u65E0\u5934 Chrome\uFF1B\u53EA\u6709\u7528\u6237\u660E\u786E\u8981\u6C42\u770B\u754C\u9762/\u8C03\u8BD5\u65F6\u624D\u4F20 headed:true\u3002",
      inputSchema: {
        type: "object",
        properties: {
          input: { type: "string", description: "\u672C\u5730\u6587\u4EF6\u7EDD\u5BF9\u8DEF\u5F84" },
          url: { type: "string", description: "\u53EF\u9009\uFF1AMeeWoo \u9875\u9762\u5730\u5740\uFF0C\u9ED8\u8BA4 beta.meewoo.me" },
          headed: { type: "boolean", default: false, description: "\u9ED8\u8BA4 false=\u65E0\u5934\u3002\u53EA\u6709\u7528\u6237\u660E\u786E\u8981\u6C42\u770B Chrome \u7A97\u53E3/\u8C03\u8BD5\u65F6\u624D\u4F20 true\u3002" }
        },
        required: ["input"]
      }
    },
    {
      name: "convert",
      description: "\u683C\u5F0F\u8F6C\u6362\uFF1A\u628A\u672C\u5730\u52A8\u753B\u6587\u4EF6\u8F6C\u6210\u6307\u5B9A\u76EE\u6807\u683C\u5F0F\uFF0C\u8FD4\u56DE\u4EA7\u7269\u672C\u5730\u8DEF\u5F84\uFF08MeeWoo \u672C\u5730 CDP \u6865\uFF0C\u8D70\u5E95\u680F\u5BFC\u51FA\u5F39\u7A97\uFF09\u3002\u53EA\u60F3\u6539\u89C6\u9891\u6548\u679C / \u6309\u63A8\u8350\u503C\u5BFC\u51FA\u53CC\u901A\u9053 MP4 \u65F6\u8BF7\u7528 process\uFF0C\u4E0D\u8981\u7528\u672C\u5DE5\u5177\u3002\u9ED8\u8BA4\u65E0\u5934 Chrome\uFF1B\u53EA\u6709\u7528\u6237\u660E\u786E\u8981\u6C42\u770B\u754C\u9762/\u8C03\u8BD5\u65F6\u624D\u4F20 headed:true\u3002",
      inputSchema: {
        type: "object",
        properties: {
          input: { type: "string", description: "\u672C\u5730\u8F93\u5165\u6587\u4EF6\u7EDD\u5BF9\u8DEF\u5F84" },
          target: { type: "string", enum: listTargets(), description: "\u76EE\u6807\u683C\u5F0F" },
          out: { type: "string", description: "\u53EF\u9009\uFF1A\u4EA7\u7269\u6587\u4EF6\u8DEF\u5F84\u6216\u76EE\u5F55" },
          url: { type: "string", description: "\u53EF\u9009\uFF1AMeeWoo \u9875\u9762\u5730\u5740" },
          headed: { type: "boolean", default: false, description: "\u9ED8\u8BA4 false=\u65E0\u5934\u3002\u53EA\u6709\u7528\u6237\u660E\u786E\u8981\u6C42\u770B Chrome \u7A97\u53E3/\u8C03\u8BD5\u65F6\u624D\u4F20 true\u3002" }
        },
        required: ["input", "target"]
      }
    },
    {
      name: "process",
      description: "\u89C6\u9891\u5904\u7406\uFF1A\u5BF9\u672C\u5730 MP4 \u8D70\u300C\u8F6C\u53CC\u901A\u9053MP4 \u5BFC\u51FA\u9762\u677F \u2192 \u8C03\u6574\u5BFC\u51FA\u300D\uFF0C\u53EF\u5957\u63A8\u8350\u9884\u8BBE\uFF0C\u6216\u81EA\u5B9A\u4E49\u753B\u9762\u6DE1\u5165\u6DE1\u51FA / \u4E0A\u4E0B\u6E10\u9690 / \u97F3\u91CF / \u97F3\u91CF\u6DE1\u5165\u6DE1\u51FA / \u66FF\u6362\u97F3\u9891\uFF0C\u5E76\u5BFC\u51FA\u53CC\u901A\u9053 MP4\u3001MP4 \u6216 SVGA\u3002\u8FD9\u4E0D\u662F\u683C\u5F0F\u8F6C\u6362\uFF08\u683C\u5F0F\u8F6C\u6362\u7528 convert\uFF09\u3002\u8FD4\u56DE { file, bytes, target, fileName, width, height, fps, frames, summary }\uFF1BSVGA \u7684\u5BBD\u9AD8/\u5E27\u7387\u4E3A null\u3002\u9ED8\u8BA4\u65E0\u5934 Chrome\uFF1B\u53EA\u6709\u7528\u6237\u660E\u786E\u8981\u6C42\u770B\u754C\u9762/\u8C03\u8BD5\u65F6\u624D\u4F20 headed:true\u3002",
      inputSchema: {
        type: "object",
        properties: {
          input: { type: "string", description: "\u672C\u5730 MP4 \u6587\u4EF6\u7EDD\u5BF9\u8DEF\u5F84\uFF1B\u975E mp4 \u4F1A\u660E\u786E\u62A5\u9519" },
          preset: {
            type: "string",
            enum: PROCESS_PRESET_NAMES,
            description: "\u63A8\u8350\u9884\u8BBE\uFF08\u9875\u9762\u300C\u63A8\u8350\u503C\u5BFC\u51FA\u300D\uFF09\u3002\u4E0D\u4F20 preset \u4E14\u4E0D\u4F20\u81EA\u5B9A\u4E49\u53C2\u6570\u65F6\u9ED8\u8BA4 recommended\uFF1B\u4E0E effects / target / replacement \u4E92\u65A5"
          },
          effects: EFFECTS_SCHEMA,
          target: {
            type: "string",
            enum: PROCESS_TARGET_NAMES,
            default: "dual-mp4",
            description: "\u5BFC\u51FA\u76EE\u6807\uFF1B\u81EA\u5B9A\u4E49\u6A21\u5F0F\u7F3A\u7701 dual-mp4\u3002dual-mp4 \u4EA7\u7269\u5BBD\u5EA6\u662F\u5185\u5BB9\u5BBD\u5EA6 2 \u500D"
          },
          replacement: {
            type: "string",
            description: "\u53EF\u9009\uFF1A\u66FF\u6362\u97F3\u9891\u6587\u4EF6\u7EDD\u5BF9\u8DEF\u5F84\uFF08mp3 / wav / m4a / aac\uFF09\uFF1B\u66FF\u6362\u540E\u539F\u58F0\u9759\u97F3\uFF0C\u81EA\u52A8\u88C1\u8865\u5230\u89C6\u9891\u65F6\u957F"
          },
          out: { type: "string", description: "\u53EF\u9009\uFF1A\u4EA7\u7269\u6587\u4EF6\u8DEF\u5F84\u6216\u76EE\u5F55" },
          url: { type: "string", description: "\u53EF\u9009\uFF1AMeeWoo \u9875\u9762\u5730\u5740" },
          headed: { type: "boolean", default: false, description: "\u9ED8\u8BA4 false=\u65E0\u5934\u3002\u53EA\u6709\u7528\u6237\u660E\u786E\u8981\u6C42\u770B Chrome \u7A97\u53E3/\u8C03\u8BD5\u65F6\u624D\u4F20 true\u3002" },
          timeoutMs: { type: "number", description: `\u53EF\u9009\uFF1A\u5BFC\u51FA\u7B49\u5F85\u4E0A\u9650\uFF08\u6BEB\u79D2\uFF09\uFF0C\u9ED8\u8BA4 ${DEFAULT_TIMEOUT_MS}` }
        },
        required: ["input"]
      }
    }
  ];
}
function send(message) {
  process.stdout.write(`${JSON.stringify(message)}
`);
}
function reply(id, result) {
  send({ jsonrpc: "2.0", id, result });
}
function replyError(id, code, message) {
  send({ jsonrpc: "2.0", id, error: { code, message } });
}
async function handleToolCall(id, params) {
  const name = params?.name;
  const args = params?.arguments || {};
  try {
    let result;
    if (name === "probe") {
      result = await probeFile(args.input, { url: args.url || DEFAULT_URL, headed: args.headed });
    } else if (name === "convert") {
      result = await convertFile(args.input, args.target, {
        out: args.out,
        url: args.url || DEFAULT_URL,
        headed: args.headed
      });
    } else if (name === "process") {
      const hasCustom = args.effects !== void 0 || args.target !== void 0 || args.replacement !== void 0;
      const preset = args.preset === void 0 && !hasCustom ? "recommended" : args.preset;
      resolveProcessPlan({
        preset,
        effects: args.effects,
        target: args.target,
        replacement: args.replacement
      });
      result = await processFile(args.input, {
        preset,
        effects: args.effects,
        target: args.target,
        replacement: args.replacement,
        out: args.out,
        url: args.url || DEFAULT_URL,
        timeoutMs: resolveTimeoutMs(args.timeoutMs),
        headed: args.headed
      });
    } else {
      throw new Error(`\u672A\u77E5\u5DE5\u5177\uFF1A${name}`);
    }
    reply(id, { content: [{ type: "text", text: JSON.stringify(result) }], isError: false });
  } catch (error) {
    reply(id, { content: [{ type: "text", text: error.message || String(error) }], isError: true });
  }
}
function startMcp() {
  const rl = (0, import_node_readline.createInterface)({ input: process.stdin, crlfDelay: Infinity });
  rl.on("line", async (line) => {
    const text = line.trim();
    if (!text) return;
    let message;
    try {
      message = JSON.parse(text);
    } catch {
      send({ jsonrpc: "2.0", id: null, error: { code: -32700, message: "Parse error" } });
      return;
    }
    const { id, method, params } = message;
    if (method === "initialize") {
      reply(id, {
        protocolVersion: params?.protocolVersion || "2024-11-05",
        capabilities: { tools: {} },
        serverInfo: { name: "meewoo", version: VERSION },
        instructions: "MeeWoo Agent \u66B4\u9732 probe\uFF08\u53EA\u8BFB\u63A2\u6D4B\uFF09/ convert\uFF08\u683C\u5F0F\u8F6C\u6362\uFF09/ process\uFF08\u89C6\u9891\u5904\u7406\uFF1A\u63A8\u8350\u9884\u8BBE\u6216\u81EA\u5B9A\u4E49\u6548\u679C\uFF0C\u5BFC\u51FA\u53CC\u901A\u9053 MP4 / MP4 / SVGA\uFF09\u4E09\u4E2A\u5DE5\u5177\u3002\u9ED8\u8BA4\u65E0\u5934 Chrome\u3002\u53EA\u6709\u7528\u6237\u660E\u786E\u8981\u6C42\u770B\u754C\u9762/\u8C03\u8BD5\u65F6\uFF0C\u624D\u5728\u5DE5\u5177\u53C2\u6570\u4F20 headed:true\u3002"
      });
      return;
    }
    if (method === "notifications/initialized" || method === "initialized") return;
    if (method === "ping") {
      reply(id, {});
      return;
    }
    if (method === "tools/list") {
      reply(id, { tools: toolDefinitions() });
      return;
    }
    if (method === "tools/call") {
      await handleToolCall(id, params);
      return;
    }
    if (method === "shutdown") {
      reply(id, {});
      return;
    }
    if (method === "exit") {
      process.exit(0);
    }
    replyError(id, -32601, `Method not found: ${method}`);
  });
}
async function main() {
  const argv = process.argv.slice(2);
  const command = argv[0];
  if (!command || command === "--help" || command === "-h" || command === "help") {
    process.stdout.write(usage());
    return;
  }
  if (command === "--version" || command === "-v") {
    process.stdout.write(`${VERSION}
`);
    return;
  }
  if (command === "probe") {
    await runProbe(argv.slice(1));
    return;
  }
  if (command === "convert") {
    await runConvert(argv.slice(1));
    return;
  }
  if (command === "process") {
    await runProcess(argv.slice(1));
    return;
  }
  if (command === "mcp") {
    startMcp();
    return;
  }
  if (command === "doctor") {
    runDoctor();
    return;
  }
  throw new Error(`\u672A\u77E5\u547D\u4EE4\uFF1A${command}

${usage()}`);
}
main().catch((error) => {
  process.stderr.write(`[meewoo-agent] ${error.message || String(error)}
`);
  process.exit(1);
});
