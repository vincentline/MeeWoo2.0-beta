#!/usr/bin/env bash
set -euo pipefail
echo "MeeWoo Agent"
if command -v node >/dev/null 2>&1; then
  echo "Node: $(node --version)"
else
  echo "警告：没有找到 Node，请先安装 Node 18+。" >&2
fi
if command -v google-chrome >/dev/null 2>&1 || command -v chromium >/dev/null 2>&1 || [ -d "/Applications/Google Chrome.app" ]; then
  echo "Chrome: found"
else
  echo "警告：没有找到 Chrome/Chromium；可设置 MEEWOO_CHROME。" >&2
fi
echo ""
echo "用法："
echo "  node ./meewoo-agent.cjs probe ./demo.svga"
echo "  node ./meewoo-agent.cjs convert ./demo.svga --target gif --out ./out"
echo "  node ./meewoo-agent.cjs process ./demo.mp4 --preset recommended --out ./out"
echo ""
echo "MCP 配置见 README.md。"
