# MeeWoo Agent

让本地 Agent 通过 **CLI / MCP** 调用 MeeWoo 2.0 的格式探测、格式转换与视频处理能力。

- **不依赖 Playwright**：CDP 直连本机 Chrome/Chromium
- 单文件，不需要 `npm install`
- **Windows / macOS / Linux 通用**；本机需要 Node 18+ 和 Chrome/Chromium

## 安装自检

```bash
node install.mjs
# 或直接看环境
node meewoo-agent.cjs doctor
```

`doctor` 会输出平台、Node 版本和探测到的 Chrome 路径。macOS 默认会找
`/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`，也支持用户目录下的 Chrome/Chromium。

## 快速开始

```bash
# 探测文件（只读）
node meewoo-agent.cjs probe ./demo.svga

# 格式转换（走底栏导出弹窗）
node meewoo-agent.cjs convert ./demo.svga --target gif --out ./out

# 视频处理：按页面「推荐值导出」导出双通道 MP4（只支持 mp4 源）
node meewoo-agent.cjs process ./demo.mp4 --preset recommended --out ./out
```

可用转换目标：`mp4` / `dual-mp4` / `svga` / `frames` / `gif` / `webp`。

## 视频处理（process）

`process` 与 `convert` 是两条真实链路，不要混用：

| 命令 | 链路 | 适用 |
|---|---|---|
| `convert` | 底栏导出弹窗 | 原样转格式 |
| `process` | 编辑 → 视频处理 → 推荐值导出 | 给 MP4 套推荐效果（画面/音频淡入淡出、上下渐隐、音量 80%、双通道 MP4） |

```bash
node meewoo-agent.cjs process <file.mp4> --preset recommended [--out <path>] [--timeout <seconds>] [--headed] [--url <url>]
```

- **只支持 mp4 源**：视频处理的「编辑」入口只对 MP4 开放；其他格式会明确报错，不会产文件。
- **预设只传名字**：`--preset recommended`，具体参数由页面 `createRecommendedProcessingState` 决定，工具不复制数字。
- **显式参数未实现**：`--target` / `--fps` / `--quality` / `--fade-*` / `--volume` 是预留签名，传了会报「暂不支持」，不会静默忽略。
- **产物判定**：导出前记下载目录基线，完成后只认新增文件，并要求名字匹配 `*-processed.mp4`；同后缀旧文件不会串台。
- **失败要响亮**：读到视频处理底栏的失败文案立即报错并以非 0 退出，不会干等满超时。
- **超时**：导出等待默认 600 秒，可用 `--timeout <秒>`（MCP 用 `timeoutMs`，单位毫秒）调整。

成功时返回固定结构（宽高 / 帧率 / 帧数从产物容器读回，读不到为 `null`）：

```json
{
  "file": "D:\\out\\视频 12-processed.mp4",
  "bytes": 4221115,
  "target": "dual-mp4",
  "width": 1440,
  "height": 1280,
  "fps": 30,
  "frames": 242,
  "summary": "画面淡入 0.5s · 画面淡出 0.5s · 上下渐隐 8% / 8% · 音量 80% · 音频淡入 1.0s · 音频淡出 1.0s · 时长 8.1s"
}
```

## 无头 / 有头

默认**无头 Chrome**，不弹窗口。只有用户明确要求看界面/调试时才开有头：

```bash
node meewoo-agent.cjs probe ./demo.svga --headed
node meewoo-agent.cjs convert ./demo.svga --target gif --out ./out --headed
node meewoo-agent.cjs process ./demo.mp4 --preset recommended --out ./out --headed
# 或进程级
MEEWOO_HEADED=1 node meewoo-agent.cjs probe ./demo.svga
```

MCP 工具对应参数：`headed: true`（默认 false）。

## MCP 配置

把下面这段加到支持 MCP 的 Agent 配置里（路径换成解压目录的绝对路径）：

```json
{
  "mcpServers": {
    "meewoo": {
      "command": "node",
      "args": ["<解压目录>/meewoo-agent.cjs", "mcp"]
    }
  }
}
```

MCP 暴露三个工具：`probe`（只读探测）、`convert`（格式转换）、`process`（视频处理推荐值导出）。

`process` 调用示例：

```json
{
  "name": "process",
  "arguments": {
    "input": "D:\\video\\demo.mp4",
    "preset": "recommended",
    "out": "D:\\video\\out"
  }
}
```

> macOS 上用 nvm / Homebrew 装的 Node，图形界面 MCP 客户端可能找不到 `node`；
> 把 `"command": "node"` 换成 `which node` 的绝对路径即可。

## 说明

- 默认打开 `https://beta.meewoo.me/`；可用 `--url` 指向本地 docs 服务
- 每个命令会启动一个独立的临时 Chrome 实例，不碰日常浏览器
- 首次转换 / 大文件可能需要较长时间，默认超时 10 分钟（process 可用 `--timeout` 调整）
- 自动下载会落到临时目录，再复制到 `--out` 指定的位置；工具只清理自己创建的临时目录
- 本工具只做「浏览器自动化 + 文件搬运」，不上传文件到任何服务器

## 环境变量

- `MEEWOO_CHROME`：Chrome/Chromium 可执行文件路径（自动探测失败时用）
  - macOS 示例：`/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`
- `MEEWOO_HEADED=1`：强制有头（默认无头；等价于 CLI `--headed` / MCP `headed: true`）
