# MeeWoo Agent

让本地 Agent 通过 **CLI / MCP** 调用 MeeWoo 2.0 的格式探测与转换能力。

- **不依赖 Playwright**：CDP 直连本机 Chrome/Chromium
- 单文件，不需要 `npm install`
- **Windows / macOS / Linux 通用**；本机需要 Node 18+ 和 Chrome/Chromium

## 安装自检

```bash
node install.mjs
# 或直接看环境
node meewoo-agent.cjs doctor
```

`doctor` 会输出平台、Node 版本和探测到的 Chrome 路径。macOS 默认会找
`/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`，也支持用户目录下的 Chrome/Chromium。

## 快速开始

```bash
# 探测文件
node meewoo-agent.cjs probe ./demo.svga

# 转 GIF
node meewoo-agent.cjs convert ./demo.svga --target gif --out ./out
```

可用目标：`mp4` / `dual-mp4` / `svga` / `frames` / `gif` / `webp`。

## MCP 配置

把下面这段加到支持 MCP 的 Agent 配置里（路径换成解压目录的绝对路径）：

```json
{
  "mcpServers": {
    "meewoo": {
      "command": "node",
      "args": ["<解压目录>/meewoo-agent.cjs", "mcp"]
    }
  }
}
```

MCP 暴露两个工具：`probe`、`convert`。

> macOS 上用 nvm / Homebrew 装的 Node，图形界面 MCP 客户端可能找不到 `node`；
> 把 `"command": "node"` 换成 `which node` 的绝对路径即可。

## 说明

- 默认打开 `https://beta.meewoo.me/`；可用 `--url` 指向本地 docs 服务
- 每个命令会启动一个独立的临时 Chrome 实例，不碰日常浏览器
- 首次转换 / 大文件可能需要较长时间，默认超时 10 分钟
- 自动下载会落到临时目录，再复制到 `--out` 指定的位置
- 本工具只做「浏览器自动化 + 文件搬运」，不上传文件到任何服务器

## 环境变量

- `MEEWOO_CHROME`：Chrome/Chromium 可执行文件路径（自动探测失败时用）
  - macOS 示例：`/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`
