# MeeWoo Agent

让本地 Agent 通过 **CLI / MCP** 调用 MeeWoo 2.0 的格式探测、格式转换与视频处理能力。

- **不依赖 Playwright**：CDP 直连本机 Chrome/Chromium
- 单文件，不需要 `npm install`
- **Windows / macOS / Linux 通用**；本机需要 Node 18+ 和 Chrome/Chromium

## 安装自检

```bash
node install.mjs
# 或直接看环境
node meewoo-agent.cjs doctor
```

`doctor` 会输出平台、Node 版本和探测到的 Chrome 路径。macOS 默认会找
`/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`，也支持用户目录下的 Chrome/Chromium。

## 快速开始

```bash
# 探测文件（只读）
node meewoo-agent.cjs probe ./demo.svga

# 格式转换（走底栏导出弹窗）
node meewoo-agent.cjs convert ./demo.svga --target gif --out ./out

# 视频处理：按页面「推荐值导出」导出双通道 MP4（只支持 mp4 源）
node meewoo-agent.cjs process ./demo.mp4 --preset recommended --out ./out

# 视频处理：自定义效果 + 目标（不传 --effects 时效果走推荐预设）
node meewoo-agent.cjs process ./demo.mp4 \
  --effects '{"fade":{"enabled":true,"in":0.5,"out":0.5},"edge":{"enabled":true,"top":8,"bottom":8},"audio":{"enabled":true,"volumePercent":80,"fade":{"enabled":true,"in":1,"out":1}}}' \
  --target mp4 --replacement ./bgm.mp3 --out ./out
```

可用转换目标：`mp4` / `dual-mp4` / `svga` / `frames` / `gif` / `webp`。

## 视频处理（process）

`process` 与 `convert` 是两条真实链路，不要混用：

| 命令 | 链路 | 适用 |
|---|---|---|
| `convert` | 底栏导出弹窗 | 原样转格式 |
| `process` | 「转双通道MP4」导出面板 → 底部「调整导出」→ 视频处理弹窗 | 给 MP4 套效果（画面/音频淡入淡出、上下渐隐、音量、替换音频），导出双通道 MP4 / MP4 / SVGA |

```bash
# 推荐预设：固定双通道 MP4
node meewoo-agent.cjs process <file.mp4> --preset recommended [--out <path>] [--timeout <seconds>] [--headed] [--url <url>]

# 自定义效果：target 缺省 dual-mp4；不传 --effects 时效果走推荐预设
node meewoo-agent.cjs process <file.mp4> [--effects <json>] [--target <dual-mp4|mp4|svga>] [--replacement <audio>] [--out <path>] [--timeout <seconds>] [--headed] [--url <url>]
```

- **只支持 mp4 源**：视频处理入口只对 MP4 开放；其他格式会明确报错，不会产文件。
- **参数互斥**：`--preset` 不能和 `--effects` / `--target` / `--replacement` 同时用。自定义模式至少给一项。
- **不传 effects = 推荐预设**：只想换目标（比如普通 MP4）或只替换音频时，效果仍是推荐值（画面 0.5/0.5s、上下 8%/8%、音频 1/1s、音量 80%）。
- **effects 形状**（字段名按 CLI 习惯缩短，语义与页面 `VideoEffectSpec` 一致）：

  ```json
  {
    "fade":  { "enabled": true, "in": 0.5, "out": 0.5 },
    "edge":  { "enabled": true, "top": 8, "bottom": 8 },
    "audio": { "enabled": true, "volume": 0.8, "volumePercent": 80, "fade": { "enabled": true, "in": 1, "out": 1 } }
  }
  ```

  - `fade` / `edge` / `audio` 三段都可省略；某段出现但没写 `enabled` 时视为 `true`；
  - `fade.in/out` 与 `audio.fade.in/out` 单位是秒（0–5；页面再按素材时长一半收敛）；
  - `edge.top/bottom` 是视频高度百分比（单边 0–50）；
  - `audio.volume` 是 0–1；也可以写 `audio.volumePercent` 0–100，二者只能选一个；
  - 也接受 `fadeIn` / `fadeOut` / `topPercent` / `bottomPercent` 这些全称别名；
  - 未知字段、类型错、超范围一律报错，不静默丢弃。
- **target**：`dual-mp4`（双通道 MP4，产物宽度是内容宽度 2 倍）/ `mp4`（无透明，渐隐按播放器背景色填底）/ `svga`（PNG 序列帧 + 内嵌 MP3）。
- **替换音频**：`--replacement <file>`，只认 MP3 / WAV / M4A / AAC；替换后原声静音，页面自动裁补到视频时长。
- **产物判定**：导出前记临时下载目录基线，完成后只认新增文件，并要求名字匹配 `*-processed.<ext>`；同后缀旧文件不会串台。
- **进度与失败**：确认导出后两层浮层关闭，任务进右上角导出队列；桥等队列成功才点「下载」。页面报失败立即抛错，不会干等满超时。
- **超时**：导出等待默认 600 秒，可用 `--timeout <秒>`（MCP 用 `timeoutMs`，单位毫秒）调整；超时错误会带上页面当前进度。
- **清理**：每次都是独立临时 Chrome + 临时下载目录，结束（含失败 / 超时）后重试清理，不残留 profile。

成功时返回固定结构（宽高 / 帧率 / 帧数从 MP4 容器读回，读不到为 `null`；SVGA 不做容器读数，四项均为 `null`）：

```json
{
  "file": "D:\\out\\视频 12-processed.mp4",
  "bytes": 4221115,
  "target": "dual-mp4",
  "fileName": "视频 12-processed.mp4",
  "width": 1440,
  "height": 1280,
  "fps": 30,
  "frames": 242,
  "summary": "画面淡入 0.5s · 画面淡出 0.5s · 上下渐隐 8% / 8% · 音量 80% · 音频淡入 1.0s · 音频淡出 1.0s · 时长 8.1s"
}
```

> `summary` 是自定义模式导出的底栏摘要；推荐预设返回 `null`（预设由页面计算，桥不复制数字）。

## 无头 / 有头

默认**无头 Chrome**，不弹窗口。只有用户明确要求看界面/调试时才开有头：

```bash
node meewoo-agent.cjs probe ./demo.svga --headed
node meewoo-agent.cjs convert ./demo.svga --target gif --out ./out --headed
node meewoo-agent.cjs process ./demo.mp4 --preset recommended --out ./out --headed
# 或进程级
MEEWOO_HEADED=1 node meewoo-agent.cjs probe ./demo.svga
```

MCP 工具对应参数：`headed: true`（默认 false）。

## MCP 配置

把下面这段加到支持 MCP 的 Agent 配置里（路径换成解压目录的绝对路径）：

```json
{
  "mcpServers": {
    "meewoo": {
      "command": "node",
      "args": ["<解压目录>/meewoo-agent.cjs", "mcp"]
    }
  }
}
```

MCP 暴露三个工具：`probe`（只读探测）、`convert`（格式转换）、`process`（视频处理：推荐预设或自定义效果，导出双通道 MP4 / MP4 / SVGA）。

`process` 调用示例（只传 `input` 时等价于推荐预设；要自定义就传 `effects` / `target` / `replacement`）：

```json
{
  "name": "process",
  "arguments": {
    "input": "D:\\video\\demo.mp4",
    "effects": {
      "fade": { "enabled": true, "in": 0.5, "out": 0.5 },
      "edge": { "enabled": true, "top": 8, "bottom": 8 },
      "audio": { "enabled": true, "volumePercent": 80, "fade": { "enabled": true, "in": 1, "out": 1 } }
    },
    "target": "svga",
    "replacement": "D:\\audio\\bgm.mp3",
    "out": "D:\\video\\out"
  }
}
```

> macOS 上用 nvm / Homebrew 装的 Node，图形界面 MCP 客户端可能找不到 `node`；
> 把 `"command": "node"` 换成 `which node` 的绝对路径即可。

## 说明

- 默认打开 `https://beta.meewoo.me/`；可用 `--url` 指向本地 docs 服务
- 每个命令会启动一个独立的临时 Chrome 实例，不碰日常浏览器
- 首次转换 / 大文件可能需要较长时间，默认超时 10 分钟（process 可用 `--timeout` 调整）
- 自动下载会落到临时目录，再复制到 `--out` 指定的位置；工具只清理自己创建的临时目录
- 本工具只做「浏览器自动化 + 文件搬运」，不上传文件到任何服务器

## 环境变量

- `MEEWOO_CHROME`：Chrome/Chromium 可执行文件路径（自动探测失败时用）
  - macOS 示例：`/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`
- `MEEWOO_HEADED=1`：强制有头（默认无头；等价于 CLI `--headed` / MCP `headed: true`）
