#!/usr/bin/env node
/**
 * 跨平台安装自检：Windows / macOS / Linux 都用同一条命令。
 * 只检查 Node 与 Chrome，不写系统配置、不装服务。
 */
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const agent = path.join(root, 'meewoo-agent.cjs');
const doctor = spawnSync(process.execPath, [agent, 'doctor'], { encoding: 'utf8' });

process.stdout.write('MeeWoo Agent\n\n');
if (doctor.stdout) process.stdout.write(doctor.stdout);
if (doctor.stderr) process.stderr.write(doctor.stderr);

let info = null;
try {
  info = JSON.parse(doctor.stdout || '{}');
} catch {
  // doctor 输出不是 JSON 时保持 null，下面按未就绪处理
}

if (!info?.ok) {
  console.error('\n没有找到 Chrome/Chromium。');
  console.error('macOS 默认路径：/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');
  console.error('也可以设置 MEEWOO_CHROME 指向 Chrome/Chromium 可执行文件。');
  process.exitCode = 1;
} else {
  console.log('\n检查通过。下一步：');
  console.log('  node meewoo-agent.cjs probe ./demo.svga');
  console.log('  node meewoo-agent.cjs convert ./demo.svga --target gif --out ./out');
  console.log('  node meewoo-agent.cjs process ./demo.mp4 --preset recommended --out ./out');
  console.log('\nMCP 配置见 README.md；Windows 与 macOS 命令相同。');
}
