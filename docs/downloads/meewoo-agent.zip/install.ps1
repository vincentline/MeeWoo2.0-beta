$ErrorActionPreference = 'Stop'
Write-Host 'MeeWoo Agent'
try {
  $nodeVersion = (node --version).Trim()
  Write-Host "Node: $nodeVersion"
} catch {
  Write-Warning '没有找到 Node。请先安装 Node 18+。'
}
$chrome = @(
  'C:\Program Files\Google\Chrome\Application\chrome.exe',
  'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
  'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($chrome) {
  Write-Host "Chrome: $chrome"
} else {
  Write-Warning '没有找到 Chrome/Chromium。请安装 Chrome，或设置 MEEWOO_CHROME。'
}
Write-Host ''
Write-Host '用法：'
Write-Host '  node .\meewoo-agent.cjs probe .\demo.svga'
Write-Host '  node .\meewoo-agent.cjs convert .\demo.svga --target gif --out .\out'
Write-Host '  node .\meewoo-agent.cjs process .\demo.mp4 --preset recommended --out .\out'
Write-Host '  node .\meewoo-agent.cjs process .\demo.mp4 --effects ''{"fade":{"enabled":true,"in":0.5,"out":0.5}}'' --target mp4 --out .\out'
Write-Host ''
Write-Host 'MCP 配置见 README.md。'
